
  # Questionnaire Template

  This is a code bundle for Questionnaire Template. The original project is available at https://www.figma.com/design/vkzpwSwQj91bHsZcgNsBtE/Questionnaire-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  