import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-cfcad018/health", (c) => {
  return c.json({ status: "ok" });
});

// Email endpoint for wardrobe research data
app.post("/make-server-cfcad018/send-research-data", async (c) => {
  try {
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    
    console.log('Email endpoint called');
    console.log('API Key present:', !!resendApiKey);
    console.log('API Key length:', resendApiKey?.length || 0);
    console.log('API Key starts with:', resendApiKey?.substring(0, 7));
    
    if (!resendApiKey) {
      console.error('RESEND_API_KEY environment variable is not set');
      return c.json({ 
        success: false, 
        error: 'Email service not configured. Please set up RESEND_API_KEY.' 
      }, 500);
    }

    const body = await c.req.json();
    const { sessionId, csvData, jsonData, itemsCompleted } = body;

    console.log('Sending email for session:', sessionId);
    console.log('Items completed:', itemsCompleted);

    // Prepare email payload
    const emailPayload = {
      from: 'Wardrobe Research <onboarding@resend.dev>',
      to: ['hamed.m.nigje@gmail.com'],
      subject: `Wardrobe Mirror Research Data - Session ${sessionId.substring(0, 12)}`,
      html: `
        <h2>New Wardrobe Mirror Research Submission</h2>
        <p><strong>Session ID:</strong> ${sessionId}</p>
        <p><strong>Items Completed:</strong> ${itemsCompleted}</p>
        <p><strong>Timestamp:</strong> ${new Date().toISOString()}</p>
        <hr>
        <p>Data files are attached to this email:</p>
        <ul>
          <li>wardrobe-data.csv - Spreadsheet format</li>
          <li>wardrobe-data.json - Complete JSON data</li>
        </ul>
      `,
      attachments: [
        {
          filename: `wardrobe-data-${sessionId.substring(0, 12)}.csv`,
          content: btoa(csvData),
        },
        {
          filename: `wardrobe-data-${sessionId.substring(0, 12)}.json`,
          content: btoa(JSON.stringify(jsonData, null, 2)),
        },
      ],
    };

    console.log('Email payload prepared, calling Resend API...');

    // Send email using Resend API
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailPayload),
    });

    console.log('Resend API response status:', response.status);
    
    const result = await response.json();
    console.log('Resend API response:', result);

    if (response.ok) {
      console.log(`✅ Email sent successfully for session ${sessionId}`);
      return c.json({ success: true, emailId: result.id });
    } else {
      console.error('❌ Resend API error:', result);
      return c.json({ 
        success: false, 
        error: result.message || 'Failed to send email' 
      }, response.status);
    }

  } catch (error) {
    console.error('❌ Error sending research data email:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

Deno.serve(app.fetch);