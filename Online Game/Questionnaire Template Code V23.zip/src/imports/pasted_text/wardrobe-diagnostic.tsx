/**
 * ============================================================================
 * WARDROBE MIRROR - ITEM-BASED DIAGNOSTIC (UPDATED)
 * ============================================================================
 * 
 * A mobile garment diagnostic tool exploring wardrobe behavior through
 * item-by-item questioning with a Modern-Naturalist research aesthetic.
 * 
 * Flow: Entry Image → Path Selection → Detailed Questions → Loop or Reflect
 * 
 * ============================================================================
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, Check, X, Info, Download, FileDown, RotateCcw,
  Sparkles, TrendingUp, Package, Scissors, ShoppingBag, Home,
  Heart, Wrench, DoorOpen, Compass
} from 'lucide-react';
import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  PolarRadiusAxis
} from 'recharts';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface ValueMeters {
  social: number;
  emotional: number;
  functional: number;
  inflowOutflow: number;
}

interface GarmentItem {
  id: string;
  name: string;
  image: string;
  category: string;
}

interface ItemResponse {
  itemId: string;
  itemName: string;
  ownership: 'wear-often' | 'rarely-wear' | 'discarded' | 'never-owned';
  // Path A & B (Owned)
  price?: 'free' | '1-20' | '21-50' | '51-100' | '100+';
  age?: 'less-3-months' | '3-12-months' | '1-2-years' | '2-5-years' | '5+-years';
  inflow?: 'bought-new' | 'bought-secondhand' | 'gift' | 'borrowed-shared' | 'made-it';
  care?: string[]; // ['machine-wash', 'hand-wash', 'dry-clean', 'air-dry', 'tumble-dry']
  // Path A specific (Wear often)
  frequency?: 'daily' | 'several-per-week' | 'weekly' | 'monthly';
  repaired?: 'yes-myself' | 'yes-professionally' | 'no-but-would' | 'no';
  // Path B specific (Rarely wear)
  whyNotWear?: string[]; // ['doesnt-fit', 'out-of-style', 'seasonal', 'forgot', 'other']
  reactivation?: string[]; // ['fit-better', 'was-repaired', 'styled-differently', 'reminded', 'probably-not']
  futurePlan?: 'keep' | 'repair-repurpose' | 'gift-donate' | 'sell' | 'throw-away';
  // Path C (Discarded)
  hadBefore?: 'yes' | 'no';
  whyDiscard?: string[]; // ['worn-out', 'damaged', 'didnt-fit', 'out-of-style', 'lost-interest', 'other']
  whatDidWithIt?: string; // ['threw-away', 'donated', 'sold', 'recycled', 'gave-to-someone']
  timestamp: string;
}

interface GameData {
  sessionId: string;
  timestamp: string;
  itemsCompleted: number;
  finalValues: ValueMeters;
  responses: ItemResponse[];
  persona?: string;
}

type GameState = 'welcome' | 'item-entry' | 'path-question' | 'item-loop-end' | 'reflection';
type QuestionPath = 'A' | 'B' | 'C' | null;

interface Persona {
  name: string;
  description: string;
  icon: string;
  insight: string;
  researchProfile: {
    acquisitionPattern: string;
    retentionBehavior: string;
    disposalTrigger: string;
    flowRate: string;
  };
}

// ============================================================================
// CONSTANTS & GARMENT DATABASE
// ============================================================================

const COLORS = {
  parchment: '#f5f1e8',
  gold: '#d4af37',
  mossGreen: '#1a2e1a',
  slate: '#1e293b',
  slateLight: '#475569',
  slateDark: '#2d2520',
  sage: '#8a9a5b',
  glassBg: 'rgba(245, 241, 232, 0.08)',
  glassBorder: 'rgba(245, 241, 232, 0.2)',
  // Value-specific colors
  social: '#d4af37',
  emotional: '#ec4899',
  functional: '#3b82f6',
  flow: '#8a9a5b',
};

const GARMENT_ITEMS: GarmentItem[] = [
  { id: 'white-tshirt', name: 'White T-Shirt', image: '👕', category: 'basics' },
  { id: 'denim-jacket', name: 'Denim Jacket', image: '🧥', category: 'outerwear' },
  { id: 'black-jeans', name: 'Black Jeans', image: '👖', category: 'bottoms' },
  { id: 'sneakers', name: 'White Sneakers', image: '👟', category: 'footwear' },
  { id: 'sweater', name: 'Wool Sweater', image: '🧶', category: 'knitwear' },
  { id: 'dress', name: 'Little Black Dress', image: '👗', category: 'formal' },
  { id: 'hoodie', name: 'Hoodie', image: '🥼', category: 'casual' },
  { id: 'coat', name: 'Winter Coat', image: '🧥', category: 'outerwear' },
];

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function generateSessionId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function calculateItemScore(response: ItemResponse): Partial<ValueMeters> {
  let functional = 0;
  let emotional = 0;
  let social = 0;
  let inflowOutflow = 0;

  // === PATH A: WEAR OFTEN ===
  if (response.ownership === 'wear-often') {
    functional += 15; // High utility
    inflowOutflow -= 10; // Low turnover

    // Frequency metric (NEW)
    if (response.frequency === 'daily') {
      functional += 20; // Extremely high utility
      emotional += 10; // Strong attachment
      inflowOutflow -= 15; // Very low turnover
    } else if (response.frequency === 'several-per-week') {
      functional += 15;
      inflowOutflow -= 10;
    } else if (response.frequency === 'weekly') {
      functional += 10;
    }

    // Age vs Price (Value per Wear metric)
    if (response.age === '5+-years') {
      emotional += 20; // Long-term attachment
      functional += 15; // Proven performer
      inflowOutflow -= 15; // Very low turnover
    } else if (response.age === '2-5-years') {
      emotional += 15;
      functional += 10;
      inflowOutflow -= 10;
    } else if (response.age === '1-2-years') {
      emotional += 10;
      functional += 5;
    }

    // Acquisition method
    if (response.inflow === 'bought-secondhand' || response.inflow === 'made-it') {
      emotional += 15; // Conscious acquisition
      functional += 10;
      social -= 5; // Less trend-driven
      inflowOutflow -= 10;
    } else if (response.inflow === 'gift') {
      emotional += 20; // Sentimental value
      inflowOutflow -= 10;
    } else if (response.inflow === 'borrowed-shared') {
      social += 10; // Community-oriented
      inflowOutflow -= 15; // Circular economy
    } else if (response.inflow === 'bought-new') {
      social += 10;
      inflowOutflow += 5;
    }

    // Repair behavior (Stewardship metric)
    if (response.repaired === 'yes-myself' || response.repaired === 'yes-professionally') {
      functional += 20; // High care
      emotional += 15; // Attachment through repair
      inflowOutflow -= 15; // Very low disposal
    } else if (response.repaired === 'no-but-would') {
      functional += 10;
      emotional += 5;
    }

    // Price point
    if (response.price === '100+') {
      social += 10;
      functional += 5;
    } else if (response.price === 'free' || response.price === '1-20') {
      inflowOutflow += 10; // More replaceable
      emotional -= 5;
    }
  }

  // === PATH B: RARELY WEAR ===
  if (response.ownership === 'rarely-wear') {
    functional -= 20; // Low utility
    inflowOutflow += 15; // Represents clutter/stagnation

    // Why not wearing
    if (response.whyNotWear?.includes('doesnt-fit')) {
      emotional += 10; // Aspirational keeping
      inflowOutflow -= 5; // Holding pattern
    }
    if (response.whyNotWear?.includes('out-of-style')) {
      social += 15; // Social-driven
      inflowOutflow += 10; // Should cycle out
    }
    if (response.whyNotWear?.includes('forgot')) {
      functional -= 15; // Poor organization
      inflowOutflow += 5;
    }
    if (response.whyNotWear?.includes('seasonal')) {
      functional += 5; // Reasonable retention
      inflowOutflow -= 5;
    }

    // Reactivation potential (NEW)
    if (response.reactivation?.includes('probably-not')) {
      inflowOutflow += 15; // Should let go
      functional -= 10;
    } else if (response.reactivation && response.reactivation.length > 2) {
      emotional += 10; // Hope for reuse
      functional += 5;
    }

    // Future plan
    if (response.futurePlan === 'gift-donate') {
      functional += 10; // Conscious curation
      inflowOutflow += 10; // Active outflow
    } else if (response.futurePlan === 'repair-repurpose') {
      emotional += 15; // Hope for reactivation
      functional += 5;
      inflowOutflow -= 5;
    } else if (response.futurePlan === 'keep') {
      emotional += 10; // Indecision/attachment
      inflowOutflow -= 10; // Accumulation
    } else if (response.futurePlan === 'sell') {
      functional += 5; // Pragmatic
      inflowOutflow += 5;
    }

    // Age (holding unused items)
    if (response.age === '5+-years') {
      emotional += 15; // Strong attachment despite non-use
      inflowOutflow -= 15; // Accumulation
    }
  }

  // === PATH C: DISCARDED ===
  if (response.ownership === 'discarded' && response.hadBefore === 'yes') {
    inflowOutflow += 20; // High turnover

    // Why discarded
    if (response.whyDiscard?.includes('worn-out') || response.whyDiscard?.includes('damaged')) {
      functional += 10; // Performance-based disposal
    }
    if (response.whyDiscard?.includes('lost-interest') || response.whyDiscard?.includes('out-of-style')) {
      social += 10; // Trend-driven
      inflowOutflow += 10;
    }
    if (response.whyDiscard?.includes('didnt-fit')) {
      inflowOutflow += 10;
    }

    // What did with it
    if (response.whatDidWithIt === 'donated' || response.whatDidWithIt === 'gave-to-someone') {
      functional += 10; // Conscious disposal
      emotional += 5;
    } else if (response.whatDidWithIt === 'recycled') {
      functional += 15; // Very conscious
      inflowOutflow += 5;
    } else if (response.whatDidWithIt === 'sold') {
      functional += 5;
      inflowOutflow += 5;
    } else if (response.whatDidWithIt === 'threw-away') {
      inflowOutflow += 15; // Wasteful
    }
  }

  return { functional, emotional, social, inflowOutflow };
}

function aggregateValues(responses: ItemResponse[]): ValueMeters {
  const base: ValueMeters = { social: 50, emotional: 50, functional: 50, inflowOutflow: 50 };
  
  responses.forEach(response => {
    const scores = calculateItemScore(response);
    base.social += scores.social || 0;
    base.emotional += scores.emotional || 0;
    base.functional += scores.functional || 0;
    base.inflowOutflow += scores.inflowOutflow || 0;
  });

  // Clamp values
  return {
    social: Math.max(0, Math.min(100, base.social)),
    emotional: Math.max(0, Math.min(100, base.emotional)),
    functional: Math.max(0, Math.min(100, base.functional)),
    inflowOutflow: Math.max(0, Math.min(100, base.inflowOutflow)),
  };
}

function calculatePersona(values: ValueMeters, responses: ItemResponse[]): Persona {
  const { emotional, social, functional, inflowOutflow } = values;
  
  // Count repair behavior
  const repairCount = responses.filter(r => 
    r.repaired === 'yes-myself' || r.repaired === 'yes-professionally'
  ).length;
  const totalOwned = responses.filter(r => r.ownership !== 'never-owned').length;
  const repairRate = totalOwned > 0 ? repairCount / totalOwned : 0;

  // The Stitch-Witch: High repair, high emotional, low flow
  if (repairRate > 0.5 && emotional > 60 && inflowOutflow < 45) {
    return {
      name: 'The Stitch-Witch',
      icon: '🪡',
      description: 'You heal your wardrobe rather than replace it. Every mended seam is a testament to care, every repaired zipper a small victory against disposability. Your clothing holds stories of resurrection.',
      insight: 'Your repair ethic is rare and valuable. But ask: do you mend only from love, or also from fear of letting go?',
      researchProfile: {
        acquisitionPattern: 'Selective and intentional; prioritizes quality over quantity',
        retentionBehavior: 'Extends garment lifespan through active maintenance and repair',
        disposalTrigger: 'Only when beyond all repair; views disposal as last resort',
        flowRate: 'Very Low - long-term ownership with deep care investment',
      },
    };
  }

  // The Flash-Buyer: Low-price, high inflow, low wear
  const lowPriceRarelyWear = responses.filter(
    r => r.ownership === 'rarely-wear' && 
    (r.price === '1-20' || r.price === '21-50' || r.price === 'free')
  ).length;
  
  if (lowPriceRarelyWear > responses.length * 0.4 && inflowOutflow > 60) {
    return {
      name: 'The Flash-Buyer',
      icon: '⚡',
      description: 'Acquisition thrills you more than wearing. Your wardrobe accumulates faster than you can integrate. Low prices reduce purchase friction, creating a gap between buying and using.',
      insight: 'The dopamine hit of "getting a deal" may be masking unfulfilled needs. What are you really shopping for?',
      researchProfile: {
        acquisitionPattern: 'High frequency, price-driven, impulse-responsive',
        retentionBehavior: 'Accumulates unworn items; large purchase-to-wear gap',
        disposalTrigger: 'Space constraints or guilt-driven purges',
        flowRate: 'Very High inflow, low outflow - creates wardrobe bloat',
      },
    };
  }

  // The Conscious Curator: Balanced with intentional disposal
  const donationIntentions = responses.filter(r => 
    r.futurePlan === 'gift-donate' || r.whatDidWithIt === 'donated'
  ).length;
  if (donationIntentions > 1 && Math.abs(emotional - functional) < 20 && inflowOutflow > 50) {
    return {
      name: 'The Conscious Curator',
      icon: '🌱',
      description: 'You actively manage your wardrobe as a system. Acquisition is thoughtful, disposal is intentional. You understand that letting go creates space—physical and psychological—for what serves you now.',
      insight: 'Your curation creates clarity. Consider: does your wardrobe reflect who you are today, or who you used to be?',
      researchProfile: {
        acquisitionPattern: 'Need-based and values-aligned; considers lifecycle impact',
        retentionBehavior: 'Regular evaluation; keeps what serves current lifestyle',
        disposalTrigger: 'Conscious decision-making; active donation and recycling',
        flowRate: 'Moderate - balanced inflow and outflow',
      },
    };
  }

  // The Memory Keeper: High emotional, low flow, old items
  const oldItems = responses.filter(r => 
    r.age === '5+-years' || r.age === '2-5-years'
  ).length;
  
  if (oldItems > responses.length * 0.5 && emotional > 65 && inflowOutflow < 40) {
    return {
      name: 'The Memory Keeper',
      icon: '📖',
      description: 'Every garment tells a story. You hold onto pieces not for their current utility, but for the moments they represent. Your wardrobe is an archive of experiences.',
      insight: 'Your attachment creates meaning. But which stories still serve you, and which have you outgrown?',
      researchProfile: {
        acquisitionPattern: 'Sentimental or milestone-driven; low acquisition frequency',
        retentionBehavior: 'Indefinite keeping due to emotional attachment',
        disposalTrigger: 'Rarely disposes; extreme circumstances only',
        flowRate: 'Very Low - minimal turnover, high sentimental retention',
      },
    };
  }

  // The Functional Minimalist: High functional, low emotional
  if (functional > 70 && emotional < 45 && social < 50) {
    return {
      name: 'The Functional Minimalist',
      icon: '⚙️',
      description: 'Purpose drives every decision. You view clothing as tools that must earn their place through performance. Sentimentality does not cloud your judgment—what works stays, what does not goes.',
      insight: 'Your clarity is enviable. But does pure function leave room for joy, whimsy, or self-expression?',
      researchProfile: {
        acquisitionPattern: 'Need-based replacement; seeks durability and versatility',
        retentionBehavior: 'Performance-based evaluation; regular utility audits',
        disposalTrigger: 'Functional failure or better alternative available',
        flowRate: 'Low to Moderate - efficient system with clear criteria',
      },
    };
  }

  // Default: The Harmonist
  return {
    name: 'The Harmonist',
    icon: '⚖️',
    description: 'No single value dominates your wardrobe life. You balance sentiment with practicality, social awareness with personal preference. Your wardrobe reflects measured moderation.',
    insight: 'Your equilibrium is rare in a culture of extremes. Does this balance reflect contentment, or indecision?',
    researchProfile: {
      acquisitionPattern: 'Mixed motivations; context-dependent decisions',
      retentionBehavior: 'Moderate attachment; varied retention reasons',
      disposalTrigger: 'Case-by-case evaluation; no single dominant factor',
      flowRate: 'Moderate - balanced approach across all dimensions',
    },
  };
}

function exportGameData(data: GameData): void {
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `wardrobe-diagnostic-${data.sessionId}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function exportCSV(data: GameData): void {
  const headers = [
    'Session ID', 'Timestamp', 'Item Name', 'Ownership', 'Price', 'Age', 'Inflow',
    'Frequency', 'Repaired', 'Why Not Wear', 'Reactivation', 'Future Plan', 
    'Had Before', 'Why Discard', 'What Did With It'
  ];
  const rows = data.responses.map(r => [
    data.sessionId, r.timestamp, r.itemName, r.ownership, r.price || '', r.age || '',
    r.inflow || '', r.frequency || '', r.repaired || '', (r.whyNotWear || []).join(';'),
    (r.reactivation || []).join(';'), r.futurePlan || '', r.hadBefore || '', 
    (r.whyDiscard || []).join(';'), r.whatDidWithIt || ''
  ]);
  const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `wardrobe-diagnostic-${data.sessionId}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ============================================================================
// REUSABLE UI COMPONENTS
// ============================================================================

function SelectionTile({ 
  label, 
  selected, 
  onClick,
  icon,
  description 
}: { 
  label: string; 
  selected: boolean; 
  onClick: () => void;
  icon?: React.ReactNode;
  description?: string;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full p-5 rounded-2xl transition-all duration-300 text-left relative overflow-hidden"
      style={{
        background: selected 
          ? COLORS.glassBg
          : 'rgba(245, 241, 232, 0.04)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: selected ? `1px solid ${COLORS.gold}` : `1px solid ${COLORS.glassBorder}`,
        boxShadow: selected ? `0 0 30px ${COLORS.gold}40` : 'none',
      }}
    >
      <div className="flex items-start gap-3">
        {icon && (
          <div 
            className="flex-shrink-0 mt-0.5"
            style={{ color: selected ? COLORS.gold : COLORS.parchment }}
          >
            {icon}
          </div>
        )}
        <div className="flex-1">
          <div 
            className="text-base mb-1"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: selected ? COLORS.gold : COLORS.parchment,
              fontWeight: selected ? 500 : 300,
              textShadow: selected ? `0 0 10px ${COLORS.gold}50` : 'none',
            }}
          >
            {label}
          </div>
          {description && (
            <div 
              className="text-xs leading-relaxed"
              style={{ 
                fontFamily: 'Inter, sans-serif',
                color: 'rgba(245, 241, 232, 0.6)',
                letterSpacing: '0.02em',
              }}
            >
              {description}
            </div>
          )}
        </div>
        {selected && (
          <Check 
            className="w-5 h-5 flex-shrink-0" 
            style={{ color: COLORS.gold }}
            strokeWidth={2.5}
          />
        )}
      </div>
    </button>
  );
}

function MultiSelectTile({
  label,
  selected,
  onClick,
  icon,
}: {
  label: string;
  selected: boolean;
  onClick: () => void;
  icon?: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className="p-4 rounded-xl transition-all duration-300"
      style={{
        background: selected ? COLORS.gold : COLORS.glassBg,
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: `1px solid ${selected ? COLORS.gold : COLORS.glassBorder}`,
        boxShadow: selected ? `0 0 20px ${COLORS.gold}40` : 'none',
        color: selected ? COLORS.mossGreen : COLORS.parchment,
      }}
    >
      <div className="flex flex-col items-center gap-2">
        {icon}
        <span 
          className="text-xs text-center"
          style={{ fontFamily: 'Inter, sans-serif', letterSpacing: '0.02em', fontWeight: 300 }}
        >
          {label}
        </span>
      </div>
    </button>
  );
}

function ContinueButton({ 
  onClick, 
  disabled,
  label = 'Continue'
}: { 
  onClick: () => void; 
  disabled?: boolean;
  label?: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full py-4 rounded-full transition-all duration-300 flex items-center justify-center gap-2 relative overflow-hidden"
      style={{
        background: disabled 
          ? 'rgba(245, 241, 232, 0.1)'
          : `linear-gradient(135deg, ${COLORS.gold}, #b8941f)`,
        color: disabled ? 'rgba(245, 241, 232, 0.3)' : COLORS.mossGreen,
        fontFamily: 'Inter, sans-serif',
        fontSize: '0.875rem',
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        fontWeight: 500,
        boxShadow: disabled ? 'none' : `0 0 30px ${COLORS.gold}40`,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        border: `1px solid ${disabled ? COLORS.glassBorder : COLORS.gold}`,
      }}
    >
      {label}
      <ArrowRight className="w-4 h-4" strokeWidth={2} />
    </button>
  );
}

// Reusable Question Screen wrapper
function QuestionScreen({
  title,
  subtitle,
  children,
  onBack,
  hasMultiSelect = false,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  onBack?: () => void;
  hasMultiSelect?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen flex flex-col p-6 relative overflow-hidden"
      style={{ 
        background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 40%, ${COLORS.slateDark} 100%)`,
      }}
    >
      {/* Grainy texture overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none">
        <filter id='noiseFilter3'>
          <feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noiseFilter3)"/>
      </svg>

      <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-center space-y-8 relative z-10">
        {/* Back button */}
        {onBack && (
          <button
            onClick={onBack}
            className="self-start flex items-center gap-2 px-4 py-2 rounded-full transition-all"
            style={{
              background: COLORS.glassBg,
              border: `1px solid ${COLORS.glassBorder}`,
              color: COLORS.parchment,
              fontFamily: 'Inter, sans-serif',
              fontSize: '0.75rem',
            }}
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            Back
          </button>
        )}

        {/* Question Header */}
        <div className="text-center space-y-3">
          <h2 
            className="text-2xl leading-relaxed"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.parchment,
              fontWeight: 300,
            }}
          >
            {title}
          </h2>
          {subtitle && (
            <p 
              className="text-sm"
              style={{ 
                fontFamily: 'Inter, sans-serif',
                color: hasMultiSelect ? COLORS.gold : 'rgba(245, 241, 232, 0.6)',
                letterSpacing: '0.02em',
              }}
            >
              {subtitle}
            </p>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col justify-center">
          {children}
        </div>
      </div>
    </motion.div>
  );
}

// ============================================================================
// SCREEN COMPONENTS
// ============================================================================

function WelcomeScreen({ onStart }: { onStart: () => void }) {
  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden"
      style={{ 
        background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 40%, ${COLORS.slateDark} 100%)`,
      }}
    >
      {/* Grainy texture overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none">
        <filter id='noiseFilter'>
          <feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noiseFilter)"/>
      </svg>

      {/* Animated gradient orbs */}
      <motion.div
        className="absolute top-20 right-10 w-64 h-64 rounded-full"
        style={{
          background: `radial-gradient(circle, ${COLORS.gold}20 0%, transparent 70%)`,
          filter: 'blur(60px)',
        }}
        animate={{
          x: [0, 30, 0],
          y: [0, -20, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      <div className="max-w-md w-full space-y-12 text-center relative z-10">
        <div className="space-y-6">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Sparkles className="w-7 h-7" style={{ color: COLORS.gold }} strokeWidth={1.5} />
            <h1 
              className="text-4xl tracking-wide"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: COLORS.parchment,
                fontWeight: 300,
              }}
            >
              The Wardrobe<br />Mirror
            </h1>
            <Sparkles className="w-7 h-7" style={{ color: COLORS.gold }} strokeWidth={1.5} />
          </div>
          
          <div 
            className="w-20 h-px mx-auto"
            style={{ background: `linear-gradient(90deg, transparent, ${COLORS.gold} 50%, transparent)` }}
          />
          
          <p 
            className="text-sm font-light leading-relaxed"
            style={{
              fontFamily: 'Inter, sans-serif',
              letterSpacing: '0.05em',
              color: 'rgba(245, 241, 232, 0.7)',
            }}
          >
            An item-based diagnostic exploring the values<br />
            that shape your relationship with clothing
          </p>
        </div>

        <div 
          className="rounded-3xl p-8 text-left space-y-6 relative overflow-hidden"
          style={{
            background: COLORS.glassBg,
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: `1px solid ${COLORS.glassBorder}`,
          }}
        >
          <h2 
            className="text-xl tracking-wide"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.parchment,
              fontWeight: 300,
            }}
          >
            How It Works
          </h2>
          
          <div className="space-y-4 text-sm font-light leading-relaxed">
            <p style={{ fontFamily: 'Inter, sans-serif', color: 'rgba(245, 241, 232, 0.8)', letterSpacing: '0.02em' }}>
              <strong style={{ color: COLORS.gold }}>1.</strong> We'll show you images of common garments
            </p>
            <p style={{ fontFamily: 'Inter, sans-serif', color: 'rgba(245, 241, 232, 0.8)', letterSpacing: '0.02em' }}>
              <strong style={{ color: COLORS.gold }}>2.</strong> Answer questions about ownership, use, and care
            </p>
            <p style={{ fontFamily: 'Inter, sans-serif', color: 'rgba(245, 241, 232, 0.8)', letterSpacing: '0.02em' }}>
              <strong style={{ color: COLORS.gold }}>3.</strong> Explore as many items as you like
            </p>
            <p style={{ fontFamily: 'Inter, sans-serif', color: 'rgba(245, 241, 232, 0.8)', letterSpacing: '0.02em' }}>
              <strong style={{ color: COLORS.gold }}>4.</strong> Discover your wardrobe behavior profile
            </p>
          </div>
        </div>

        <ContinueButton onClick={onStart} label="Begin Diagnostic" />

        <p 
          className="text-[10px] tracking-[0.15em] uppercase font-light"
          style={{
            fontFamily: 'Inter, sans-serif',
            color: 'rgba(212, 175, 55, 0.5)',
          }}
        >
          Wardrobe Research Initiative
        </p>
      </div>
    </div>
  );
}

function ItemEntryScreen({ 
  item, 
  onSelect 
}: { 
  item: GarmentItem; 
  onSelect: (choice: 'wear-often' | 'rarely-wear' | 'never-owned') => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
      className="min-h-screen flex flex-col p-6 relative overflow-hidden"
      style={{ 
        background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 40%, ${COLORS.slateDark} 100%)`,
      }}
    >
      {/* Grainy texture overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none">
        <filter id='noiseFilter2'>
          <feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noiseFilter2)"/>
      </svg>

      <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-center space-y-12 relative z-10">
        {/* Garment Image */}
        <div 
          className="w-full aspect-square rounded-3xl flex items-center justify-center relative overflow-hidden"
          style={{
            background: COLORS.glassBg,
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: `1px solid ${COLORS.glassBorder}`,
          }}
        >
          <div 
            className="text-9xl"
            style={{ 
              filter: `drop-shadow(0 4px 30px ${COLORS.gold}40)`,
            }}
          >
            {item.image}
          </div>
          {/* Decorative corner accent */}
          <div 
            className="absolute top-4 right-4 w-12 h-12 border-t border-r opacity-30" 
            style={{ borderColor: COLORS.gold }}
          />
        </div>

        {/* Question */}
        <div className="text-center space-y-4">
          <h2 
            className="text-2xl leading-relaxed"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.parchment,
              fontWeight: 300,
            }}
          >
            Do you own something<br />like this?
          </h2>
          <p 
            className="text-sm"
            style={{ 
              fontFamily: 'Inter, sans-serif',
              color: 'rgba(245, 241, 232, 0.6)',
              letterSpacing: '0.02em',
            }}
          >
            {item.name}
          </p>
        </div>

        {/* Options */}
        <div className="space-y-3">
          <SelectionTile
            label="Yes, and I wear it often"
            selected={false}
            onClick={() => onSelect('wear-often')}
            icon={<Heart className="w-5 h-5" />}
          />
          <SelectionTile
            label="Yes, but I rarely wear it"
            selected={false}
            onClick={() => onSelect('rarely-wear')}
            icon={<Package className="w-5 h-5" />}
          />
          <SelectionTile
            label="No, I don't own this"
            selected={false}
            onClick={() => onSelect('never-owned')}
            icon={<X className="w-5 h-5" />}
          />
        </div>
      </div>
    </motion.div>
  );
}

// Question screens for Path A (Wear Often)
function PathAQuestions({
  item,
  currentQuestion,
  responses,
  onAnswer,
  onBack,
  onContinue,
}: {
  item: GarmentItem;
  currentQuestion: number;
  responses: Partial<ItemResponse>;
  onAnswer: (key: string, value: any) => void;
  onBack: () => void;
  onContinue: () => void;
}) {
  const renderQuestion = () => {
    switch (currentQuestion) {
      case 0: // A1: Price
        return (
          <QuestionScreen
            title="About how much did it cost?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Free" selected={responses.price === 'free'} onClick={() => onAnswer('price', 'free')} />
              <SelectionTile label="€1–20" selected={responses.price === '1-20'} onClick={() => onAnswer('price', '1-20')} />
              <SelectionTile label="€21–50" selected={responses.price === '21-50'} onClick={() => onAnswer('price', '21-50')} />
              <SelectionTile label="€51–100" selected={responses.price === '51-100'} onClick={() => onAnswer('price', '51-100')} />
              <SelectionTile label="€100+" selected={responses.price === '100+'} onClick={() => onAnswer('price', '100+')} />
            </div>
          </QuestionScreen>
        );

      case 1: // A2: Frequency
        return (
          <QuestionScreen
            title="How often do you wear it?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Daily" selected={responses.frequency === 'daily'} onClick={() => onAnswer('frequency', 'daily')} />
              <SelectionTile label="Several times a week" selected={responses.frequency === 'several-per-week'} onClick={() => onAnswer('frequency', 'several-per-week')} />
              <SelectionTile label="Weekly" selected={responses.frequency === 'weekly'} onClick={() => onAnswer('frequency', 'weekly')} />
              <SelectionTile label="Monthly" selected={responses.frequency === 'monthly'} onClick={() => onAnswer('frequency', 'monthly')} />
            </div>
          </QuestionScreen>
        );

      case 2: // A3: Age
        return (
          <QuestionScreen
            title="How long have you had it?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Less than 3 months" selected={responses.age === 'less-3-months'} onClick={() => onAnswer('age', 'less-3-months')} />
              <SelectionTile label="3–12 months" selected={responses.age === '3-12-months'} onClick={() => onAnswer('age', '3-12-months')} />
              <SelectionTile label="1–2 years" selected={responses.age === '1-2-years'} onClick={() => onAnswer('age', '1-2-years')} />
              <SelectionTile label="2–5 years" selected={responses.age === '2-5-years'} onClick={() => onAnswer('age', '2-5-years')} />
              <SelectionTile label="5+ years" selected={responses.age === '5+-years'} onClick={() => onAnswer('age', '5+-years')} />
            </div>
          </QuestionScreen>
        );

      case 3: // A4: Inflow
        return (
          <QuestionScreen
            title="How did you get it?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Bought new" selected={responses.inflow === 'bought-new'} onClick={() => onAnswer('inflow', 'bought-new')} icon={<ShoppingBag className="w-5 h-5" />} />
              <SelectionTile label="Bought second-hand" selected={responses.inflow === 'bought-secondhand'} onClick={() => onAnswer('inflow', 'bought-secondhand')} icon={<TrendingUp className="w-5 h-5" />} />
              <SelectionTile label="Gift" selected={responses.inflow === 'gift'} onClick={() => onAnswer('inflow', 'gift')} icon={<Heart className="w-5 h-5" />} />
              <SelectionTile label="Borrowed / shared" selected={responses.inflow === 'borrowed-shared'} onClick={() => onAnswer('inflow', 'borrowed-shared')} icon={<Home className="w-5 h-5" />} />
              <SelectionTile label="Made it" selected={responses.inflow === 'made-it'} onClick={() => onAnswer('inflow', 'made-it')} icon={<Scissors className="w-5 h-5" />} />
            </div>
          </QuestionScreen>
        );

      case 4: // A5: Care (multi-select)
        return (
          <QuestionScreen
            title="How do you usually care for it?"
            subtitle="Select all that apply"
            onBack={onBack}
            hasMultiSelect
          >
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-3">
                <MultiSelectTile
                  label="Machine wash"
                  selected={responses.care?.includes('machine-wash') || false}
                  onClick={() => {
                    const current = responses.care || [];
                    const newCare = current.includes('machine-wash')
                      ? current.filter(c => c !== 'machine-wash')
                      : [...current, 'machine-wash'];
                    onAnswer('care', newCare);
                  }}
                />
                <MultiSelectTile
                  label="Hand wash"
                  selected={responses.care?.includes('hand-wash') || false}
                  onClick={() => {
                    const current = responses.care || [];
                    const newCare = current.includes('hand-wash')
                      ? current.filter(c => c !== 'hand-wash')
                      : [...current, 'hand-wash'];
                    onAnswer('care', newCare);
                  }}
                />
                <MultiSelectTile
                  label="Dry clean"
                  selected={responses.care?.includes('dry-clean') || false}
                  onClick={() => {
                    const current = responses.care || [];
                    const newCare = current.includes('dry-clean')
                      ? current.filter(c => c !== 'dry-clean')
                      : [...current, 'dry-clean'];
                    onAnswer('care', newCare);
                  }}
                />
                <MultiSelectTile
                  label="Air dry"
                  selected={responses.care?.includes('air-dry') || false}
                  onClick={() => {
                    const current = responses.care || [];
                    const newCare = current.includes('air-dry')
                      ? current.filter(c => c !== 'air-dry')
                      : [...current, 'air-dry'];
                    onAnswer('care', newCare);
                  }}
                />
                <MultiSelectTile
                  label="Tumble dry"
                  selected={responses.care?.includes('tumble-dry') || false}
                  onClick={() => {
                    const current = responses.care || [];
                    const newCare = current.includes('tumble-dry')
                      ? current.filter(c => c !== 'tumble-dry')
                      : [...current, 'tumble-dry'];
                    onAnswer('care', newCare);
                  }}
                />
              </div>
              <ContinueButton 
                onClick={onContinue} 
                disabled={!responses.care || responses.care.length === 0}
              />
            </div>
          </QuestionScreen>
        );

      case 5: // A6: Repair
        return (
          <QuestionScreen
            title="Have you ever repaired it?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Yes, myself" selected={responses.repaired === 'yes-myself'} onClick={() => onAnswer('repaired', 'yes-myself')} icon={<Wrench className="w-5 h-5" />} />
              <SelectionTile label="Yes, professionally" selected={responses.repaired === 'yes-professionally'} onClick={() => onAnswer('repaired', 'yes-professionally')} icon={<Scissors className="w-5 h-5" />} />
              <SelectionTile label="No, but I would" selected={responses.repaired === 'no-but-would'} onClick={() => onAnswer('repaired', 'no-but-would')} />
              <SelectionTile label="No" selected={responses.repaired === 'no'} onClick={() => onAnswer('repaired', 'no')} />
            </div>
          </QuestionScreen>
        );

      default:
        return null;
    }
  };

  return renderQuestion();
}

// Question screens for Path B (Rarely Wear)
function PathBQuestions({
  item,
  currentQuestion,
  responses,
  onAnswer,
  onBack,
  onContinue,
}: {
  item: GarmentItem;
  currentQuestion: number;
  responses: Partial<ItemResponse>;
  onAnswer: (key: string, value: any) => void;
  onBack: () => void;
  onContinue: () => void;
}) {
  const renderQuestion = () => {
    switch (currentQuestion) {
      case 0: // B1: Price
        return (
          <QuestionScreen
            title="About how much did it cost?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Free" selected={responses.price === 'free'} onClick={() => onAnswer('price', 'free')} />
              <SelectionTile label="€1–20" selected={responses.price === '1-20'} onClick={() => onAnswer('price', '1-20')} />
              <SelectionTile label="€21–50" selected={responses.price === '21-50'} onClick={() => onAnswer('price', '21-50')} />
              <SelectionTile label="€51–100" selected={responses.price === '51-100'} onClick={() => onAnswer('price', '51-100')} />
              <SelectionTile label="€100+" selected={responses.price === '100+'} onClick={() => onAnswer('price', '100+')} />
            </div>
          </QuestionScreen>
        );

      case 1: // B2: Age
        return (
          <QuestionScreen
            title="How long have you had it?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Less than 3 months" selected={responses.age === 'less-3-months'} onClick={() => onAnswer('age', 'less-3-months')} />
              <SelectionTile label="3–12 months" selected={responses.age === '3-12-months'} onClick={() => onAnswer('age', '3-12-months')} />
              <SelectionTile label="1–2 years" selected={responses.age === '1-2-years'} onClick={() => onAnswer('age', '1-2-years')} />
              <SelectionTile label="2–5 years" selected={responses.age === '2-5-years'} onClick={() => onAnswer('age', '2-5-years')} />
              <SelectionTile label="5+ years" selected={responses.age === '5+-years'} onClick={() => onAnswer('age', '5+-years')} />
            </div>
          </QuestionScreen>
        );

      case 2: // B3: Inflow
        return (
          <QuestionScreen
            title="How did you get it?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Bought new" selected={responses.inflow === 'bought-new'} onClick={() => onAnswer('inflow', 'bought-new')} icon={<ShoppingBag className="w-5 h-5" />} />
              <SelectionTile label="Bought second-hand" selected={responses.inflow === 'bought-secondhand'} onClick={() => onAnswer('inflow', 'bought-secondhand')} icon={<TrendingUp className="w-5 h-5" />} />
              <SelectionTile label="Gift" selected={responses.inflow === 'gift'} onClick={() => onAnswer('inflow', 'gift')} icon={<Heart className="w-5 h-5" />} />
              <SelectionTile label="Borrowed / shared" selected={responses.inflow === 'borrowed-shared'} onClick={() => onAnswer('inflow', 'borrowed-shared')} icon={<Home className="w-5 h-5" />} />
              <SelectionTile label="Made it" selected={responses.inflow === 'made-it'} onClick={() => onAnswer('inflow', 'made-it')} icon={<Scissors className="w-5 h-5" />} />
            </div>
          </QuestionScreen>
        );

      case 3: // B4: Why don't you wear it? (multi-select)
        return (
          <QuestionScreen
            title="Why don't you wear it often?"
            subtitle="Select all that apply"
            onBack={onBack}
            hasMultiSelect
          >
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-3">
                <MultiSelectTile
                  label="Doesn't fit"
                  selected={responses.whyNotWear?.includes('doesnt-fit') || false}
                  onClick={() => {
                    const current = responses.whyNotWear || [];
                    const newWhy = current.includes('doesnt-fit')
                      ? current.filter(w => w !== 'doesnt-fit')
                      : [...current, 'doesnt-fit'];
                    onAnswer('whyNotWear', newWhy);
                  }}
                />
                <MultiSelectTile
                  label="Out of style"
                  selected={responses.whyNotWear?.includes('out-of-style') || false}
                  onClick={() => {
                    const current = responses.whyNotWear || [];
                    const newWhy = current.includes('out-of-style')
                      ? current.filter(w => w !== 'out-of-style')
                      : [...current, 'out-of-style'];
                    onAnswer('whyNotWear', newWhy);
                  }}
                />
                <MultiSelectTile
                  label="Seasonal"
                  selected={responses.whyNotWear?.includes('seasonal') || false}
                  onClick={() => {
                    const current = responses.whyNotWear || [];
                    const newWhy = current.includes('seasonal')
                      ? current.filter(w => w !== 'seasonal')
                      : [...current, 'seasonal'];
                    onAnswer('whyNotWear', newWhy);
                  }}
                />
                <MultiSelectTile
                  label="Forgot about it"
                  selected={responses.whyNotWear?.includes('forgot') || false}
                  onClick={() => {
                    const current = responses.whyNotWear || [];
                    const newWhy = current.includes('forgot')
                      ? current.filter(w => w !== 'forgot')
                      : [...current, 'forgot'];
                    onAnswer('whyNotWear', newWhy);
                  }}
                />
                <MultiSelectTile
                  label="Other"
                  selected={responses.whyNotWear?.includes('other') || false}
                  onClick={() => {
                    const current = responses.whyNotWear || [];
                    const newWhy = current.includes('other')
                      ? current.filter(w => w !== 'other')
                      : [...current, 'other'];
                    onAnswer('whyNotWear', newWhy);
                  }}
                />
              </div>
              <ContinueButton 
                onClick={onContinue} 
                disabled={!responses.whyNotWear || responses.whyNotWear.length === 0}
              />
            </div>
          </QuestionScreen>
        );

      case 4: // B5: Reactivation (multi-select)
        return (
          <QuestionScreen
            title="Would you wear it more if…"
            subtitle="Select all that apply"
            onBack={onBack}
            hasMultiSelect
          >
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-3">
                <MultiSelectTile
                  label="It fit better"
                  selected={responses.reactivation?.includes('fit-better') || false}
                  onClick={() => {
                    const current = responses.reactivation || [];
                    const newReact = current.includes('fit-better')
                      ? current.filter(r => r !== 'fit-better')
                      : [...current, 'fit-better'];
                    onAnswer('reactivation', newReact);
                  }}
                />
                <MultiSelectTile
                  label="It was repaired"
                  selected={responses.reactivation?.includes('was-repaired') || false}
                  onClick={() => {
                    const current = responses.reactivation || [];
                    const newReact = current.includes('was-repaired')
                      ? current.filter(r => r !== 'was-repaired')
                      : [...current, 'was-repaired'];
                    onAnswer('reactivation', newReact);
                  }}
                />
                <MultiSelectTile
                  label="I styled it differently"
                  selected={responses.reactivation?.includes('styled-differently') || false}
                  onClick={() => {
                    const current = responses.reactivation || [];
                    const newReact = current.includes('styled-differently')
                      ? current.filter(r => r !== 'styled-differently')
                      : [...current, 'styled-differently'];
                    onAnswer('reactivation', newReact);
                  }}
                />
                <MultiSelectTile
                  label="I was reminded of it"
                  selected={responses.reactivation?.includes('reminded') || false}
                  onClick={() => {
                    const current = responses.reactivation || [];
                    const newReact = current.includes('reminded')
                      ? current.filter(r => r !== 'reminded')
                      : [...current, 'reminded'];
                    onAnswer('reactivation', newReact);
                  }}
                />
                <MultiSelectTile
                  label="No, probably not"
                  selected={responses.reactivation?.includes('probably-not') || false}
                  onClick={() => {
                    const current = responses.reactivation || [];
                    const newReact = current.includes('probably-not')
                      ? current.filter(r => r !== 'probably-not')
                      : [...current, 'probably-not'];
                    onAnswer('reactivation', newReact);
                  }}
                />
              </div>
              <ContinueButton 
                onClick={onContinue} 
                disabled={!responses.reactivation || responses.reactivation.length === 0}
              />
            </div>
          </QuestionScreen>
        );

      case 5: // B6: Future Plan
        return (
          <QuestionScreen
            title="What will you likely do with it?"
            subtitle={item.name}
            onBack={onBack}
          >
            <div className="space-y-3">
              <SelectionTile label="Keep it" selected={responses.futurePlan === 'keep'} onClick={() => onAnswer('futurePlan', 'keep')} icon={<Package className="w-5 h-5" />} />
              <SelectionTile label="Repair or Repurpose" selected={responses.futurePlan === 'repair-repurpose'} onClick={() => onAnswer('futurePlan', 'repair-repurpose')} icon={<Wrench className="w-5 h-5" />} />
              <SelectionTile label="Gift or Donate" selected={responses.futurePlan === 'gift-donate'} onClick={() => onAnswer('futurePlan', 'gift-donate')} icon={<Heart className="w-5 h-5" />} />
              <SelectionTile label="Sell it" selected={responses.futurePlan === 'sell'} onClick={() => onAnswer('futurePlan', 'sell')} icon={<TrendingUp className="w-5 h-5" />} />
              <SelectionTile label="Throw it away" selected={responses.futurePlan === 'throw-away'} onClick={() => onAnswer('futurePlan', 'throw-away')} icon={<X className="w-5 h-5" />} />
            </div>
          </QuestionScreen>
        );

      default:
        return null;
    }
  };

  return renderQuestion();
}

// Item loop end screen
function ItemLoopEndScreen({
  onContinue,
  onFinish,
  itemsCompleted,
}: {
  onContinue: () => void;
  onFinish: () => void;
  itemsCompleted: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4 }}
      className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden"
      style={{ 
        background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 40%, ${COLORS.slateDark} 100%)`,
      }}
    >
      {/* Grainy texture overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none">
        <filter id='noiseFilter4'>
          <feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noiseFilter4)"/>
      </svg>

      <div className="max-w-md w-full space-y-8 text-center relative z-10">
        <div className="space-y-6">
          <Sparkles className="w-12 h-12 mx-auto" style={{ color: COLORS.gold }} strokeWidth={1.5} />
          
          <h2 
            className="text-3xl leading-relaxed"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.parchment,
              fontWeight: 300,
            }}
          >
            Nice!<br />Want to try another item?
          </h2>
          
          <p 
            className="text-sm"
            style={{ 
              fontFamily: 'Inter, sans-serif',
              color: 'rgba(245, 241, 232, 0.6)',
              letterSpacing: '0.02em',
            }}
          >
            You've completed {itemsCompleted} {itemsCompleted === 1 ? 'item' : 'items'} so far
          </p>
        </div>

        <div className="space-y-3">
          <ContinueButton onClick={onContinue} label="Yes, Continue" />
          <button
            onClick={onFinish}
            className="w-full py-4 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
            style={{
              background: 'rgba(245, 241, 232, 0.04)',
              border: `1px solid ${COLORS.glassBorder}`,
              color: COLORS.parchment,
              fontFamily: 'Inter, sans-serif',
              fontSize: '0.875rem',
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              fontWeight: 500,
            }}
          >
            No, See My Results
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// Reflection/Results screen
function ReflectionScreen({
  values,
  persona,
  responses,
  onRestart,
  onExportJSON,
  onExportCSV,
}: {
  values: ValueMeters;
  persona: Persona;
  responses: ItemResponse[];
  onRestart: () => void;
  onExportJSON: () => void;
  onExportCSV: () => void;
}) {
  const radarData = [
    { axis: 'Functional', value: values.functional, fullMark: 100 },
    { axis: 'Social', value: values.social, fullMark: 100 },
    { axis: 'Emotional', value: values.emotional, fullMark: 100 },
    { axis: 'Flow Rate', value: values.inflowOutflow, fullMark: 100 },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex flex-col p-6 pb-20 relative overflow-hidden"
      style={{ 
        background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 40%, ${COLORS.slateDark} 100%)`,
      }}
    >
      {/* Grainy texture overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none">
        <filter id='noiseFilter5'>
          <feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noiseFilter5)"/>
      </svg>

      <div className="max-w-md mx-auto w-full space-y-8 relative z-10">
        {/* Header */}
        <div className="text-center space-y-4 pt-8">
          <div className="text-6xl">{persona.icon}</div>
          <h1 
            className="text-3xl leading-relaxed"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.parchment,
              fontWeight: 300,
            }}
          >
            {persona.name}
          </h1>
          <div 
            className="w-20 h-px mx-auto"
            style={{ background: `linear-gradient(90deg, transparent, ${COLORS.gold} 50%, transparent)` }}
          />
        </div>

        {/* Description */}
        <div 
          className="rounded-2xl p-6 space-y-4"
          style={{
            background: COLORS.glassBg,
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: `1px solid ${COLORS.glassBorder}`,
          }}
        >
          <p 
            className="text-sm leading-relaxed"
            style={{ 
              fontFamily: 'Inter, sans-serif',
              color: 'rgba(245, 241, 232, 0.9)',
              letterSpacing: '0.02em',
            }}
          >
            {persona.description}
          </p>
          
          <div 
            className="pt-4 border-t"
            style={{ borderColor: COLORS.glassBorder }}
          >
            <p 
              className="text-xs leading-relaxed italic"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: COLORS.gold,
              }}
            >
              {persona.insight}
            </p>
          </div>
        </div>

        {/* Radar Chart */}
        <div 
          className="rounded-2xl p-6"
          style={{
            background: COLORS.glassBg,
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: `1px solid ${COLORS.glassBorder}`,
          }}
        >
          <h3 
            className="text-center mb-4"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.parchment,
              fontSize: '1.125rem',
              fontWeight: 300,
            }}
          >
            Your Wardrobe Values
          </h3>
          <ResponsiveContainer width="100%" height={280}>
            <RadarChart data={radarData}>
              <PolarGrid stroke={COLORS.glassBorder} />
              <PolarAngleAxis 
                dataKey="axis" 
                tick={{ fill: COLORS.parchment, fontSize: 11, fontFamily: 'Inter, sans-serif' }}
              />
              <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} />
              <Radar
                name="Values"
                dataKey="value"
                stroke={COLORS.gold}
                fill={COLORS.gold}
                fillOpacity={0.3}
                strokeWidth={2}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Research Profile */}
        <div 
          className="rounded-2xl p-6 space-y-4"
          style={{
            background: COLORS.glassBg,
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: `1px solid ${COLORS.glassBorder}`,
          }}
        >
          <h3 
            className="text-center mb-4"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.parchment,
              fontSize: '1.125rem',
              fontWeight: 300,
            }}
          >
            Research Profile
          </h3>
          
          <div className="space-y-3 text-xs" style={{ fontFamily: 'Inter, sans-serif' }}>
            <div>
              <div style={{ color: COLORS.gold, fontWeight: 500, marginBottom: '0.25rem' }}>
                Acquisition Pattern
              </div>
              <div style={{ color: 'rgba(245, 241, 232, 0.8)', lineHeight: 1.5 }}>
                {persona.researchProfile.acquisitionPattern}
              </div>
            </div>
            
            <div>
              <div style={{ color: COLORS.gold, fontWeight: 500, marginBottom: '0.25rem' }}>
                Retention Behavior
              </div>
              <div style={{ color: 'rgba(245, 241, 232, 0.8)', lineHeight: 1.5 }}>
                {persona.researchProfile.retentionBehavior}
              </div>
            </div>
            
            <div>
              <div style={{ color: COLORS.gold, fontWeight: 500, marginBottom: '0.25rem' }}>
                Disposal Trigger
              </div>
              <div style={{ color: 'rgba(245, 241, 232, 0.8)', lineHeight: 1.5 }}>
                {persona.researchProfile.disposalTrigger}
              </div>
            </div>
            
            <div>
              <div style={{ color: COLORS.gold, fontWeight: 500, marginBottom: '0.25rem' }}>
                Flow Rate
              </div>
              <div style={{ color: 'rgba(245, 241, 232, 0.8)', lineHeight: 1.5 }}>
                {persona.researchProfile.flowRate}
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div 
          className="rounded-2xl p-6 text-center"
          style={{
            background: COLORS.glassBg,
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: `1px solid ${COLORS.glassBorder}`,
          }}
        >
          <div 
            className="text-4xl mb-2"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: COLORS.gold,
              fontWeight: 300,
            }}
          >
            {responses.length}
          </div>
          <div 
            className="text-xs"
            style={{ 
              fontFamily: 'Inter, sans-serif',
              color: 'rgba(245, 241, 232, 0.7)',
              letterSpacing: '0.05em',
              textTransform: 'uppercase',
            }}
          >
            Items Analyzed
          </div>
        </div>

        {/* Export Buttons */}
        <div className="space-y-3">
          <button
            onClick={onExportJSON}
            className="w-full py-3 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
            style={{
              background: 'rgba(245, 241, 232, 0.04)',
              border: `1px solid ${COLORS.glassBorder}`,
              color: COLORS.parchment,
              fontFamily: 'Inter, sans-serif',
              fontSize: '0.75rem',
              letterSpacing: '0.05em',
              textTransform: 'uppercase',
            }}
          >
            <Download className="w-4 h-4" />
            Export JSON
          </button>
          
          <button
            onClick={onExportCSV}
            className="w-full py-3 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
            style={{
              background: 'rgba(245, 241, 232, 0.04)',
              border: `1px solid ${COLORS.glassBorder}`,
              color: COLORS.parchment,
              fontFamily: 'Inter, sans-serif',
              fontSize: '0.75rem',
              letterSpacing: '0.05em',
              textTransform: 'uppercase',
            }}
          >
            <FileDown className="w-4 h-4" />
            Export CSV
          </button>
        </div>

        {/* Restart */}
        <button
          onClick={onRestart}
          className="w-full py-4 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
          style={{
            background: `linear-gradient(135deg, ${COLORS.gold}, #b8941f)`,
            color: COLORS.mossGreen,
            fontFamily: 'Inter, sans-serif',
            fontSize: '0.875rem',
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            fontWeight: 500,
            boxShadow: `0 0 30px ${COLORS.gold}40`,
            border: `1px solid ${COLORS.gold}`,
          }}
        >
          <RotateCcw className="w-4 h-4" />
          Start Over
        </button>
      </div>
    </motion.div>
  );
}

// ============================================================================
// MAIN APP COMPONENT
// ============================================================================

export default function App() {
  const [gameState, setGameState] = useState<GameState>('welcome');
  const [sessionId] = useState(generateSessionId());
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [currentPath, setCurrentPath] = useState<QuestionPath>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [currentResponse, setCurrentResponse] = useState<Partial<ItemResponse>>({});
  const [allResponses, setAllResponses] = useState<ItemResponse[]>([]);
  const [shuffledItems, setShuffledItems] = useState<GarmentItem[]>([]);

  // Initialize shuffled items
  React.useEffect(() => {
    setShuffledItems([...GARMENT_ITEMS].sort(() => Math.random() - 0.5));
  }, []);

  const currentItem = shuffledItems[currentItemIndex];

  const handleStart = () => {
    setGameState('item-entry');
  };

  const handleOwnershipSelection = (choice: 'wear-often' | 'rarely-wear' | 'never-owned') => {
    if (choice === 'never-owned') {
      // Skip to next item
      if (currentItemIndex < shuffledItems.length - 1) {
        setCurrentItemIndex(currentItemIndex + 1);
      } else {
        // No more items, go to results
        setGameState('item-loop-end');
      }
    } else {
      // Start path A or B
      setCurrentPath(choice === 'wear-often' ? 'A' : 'B');
      setCurrentResponse({
        itemId: currentItem.id,
        itemName: currentItem.name,
        ownership: choice,
        timestamp: new Date().toISOString(),
      });
      setCurrentQuestionIndex(0);
      setGameState('path-question');
    }
  };

  const handleAnswer = (key: string, value: any) => {
    const updated = { ...currentResponse, [key]: value };
    setCurrentResponse(updated);

    // Auto-advance for single-select questions
    if (key !== 'care' && key !== 'whyNotWear' && key !== 'reactivation') {
      setTimeout(() => {
        advanceQuestion();
      }, 300);
    }
  };

  const advanceQuestion = () => {
    const totalQuestions = currentPath === 'A' ? 6 : 6; // Both paths have 6 questions
    
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Path complete, save response
      setAllResponses([...allResponses, currentResponse as ItemResponse]);
      setCurrentResponse({});
      setCurrentPath(null);
      setCurrentQuestionIndex(0);
      setGameState('item-loop-end');
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    } else {
      // Go back to item entry
      setGameState('item-entry');
      setCurrentPath(null);
      setCurrentResponse({});
    }
  };

  const handleContinueLoop = () => {
    if (currentItemIndex < shuffledItems.length - 1) {
      setCurrentItemIndex(currentItemIndex + 1);
      setGameState('item-entry');
    } else {
      // No more items, go to reflection
      finishGame();
    }
  };

  const handleFinish = () => {
    finishGame();
  };

  const finishGame = () => {
    if (allResponses.length === 0) {
      // No responses, restart
      handleRestart();
      return;
    }
    setGameState('reflection');
  };

  const handleRestart = () => {
    setGameState('welcome');
    setCurrentItemIndex(0);
    setCurrentPath(null);
    setCurrentQuestionIndex(0);
    setCurrentResponse({});
    setAllResponses([]);
    setShuffledItems([...GARMENT_ITEMS].sort(() => Math.random() - 0.5));
  };

  const handleExportJSON = () => {
    const values = aggregateValues(allResponses);
    const persona = calculatePersona(values, allResponses);
    const data: GameData = {
      sessionId,
      timestamp: new Date().toISOString(),
      itemsCompleted: allResponses.length,
      finalValues: values,
      responses: allResponses,
      persona: persona.name,
    };
    exportGameData(data);
  };

  const handleExportCSV = () => {
    const values = aggregateValues(allResponses);
    const persona = calculatePersona(values, allResponses);
    const data: GameData = {
      sessionId,
      timestamp: new Date().toISOString(),
      itemsCompleted: allResponses.length,
      finalValues: values,
      responses: allResponses,
      persona: persona.name,
    };
    exportCSV(data);
  };

  // Render current screen
  if (!currentItem && gameState !== 'welcome' && gameState !== 'reflection' && gameState !== 'item-loop-end') {
    return <div>Loading...</div>;
  }

  return (
    <div className="size-full">
      <AnimatePresence mode="wait">
        {gameState === 'welcome' && (
          <WelcomeScreen key="welcome" onStart={handleStart} />
        )}

        {gameState === 'item-entry' && currentItem && (
          <ItemEntryScreen
            key={`item-${currentItem.id}`}
            item={currentItem}
            onSelect={handleOwnershipSelection}
          />
        )}

        {gameState === 'path-question' && currentPath === 'A' && currentItem && (
          <PathAQuestions
            key={`pathA-${currentQuestionIndex}`}
            item={currentItem}
            currentQuestion={currentQuestionIndex}
            responses={currentResponse}
            onAnswer={handleAnswer}
            onBack={handleBack}
            onContinue={advanceQuestion}
          />
        )}

        {gameState === 'path-question' && currentPath === 'B' && currentItem && (
          <PathBQuestions
            key={`pathB-${currentQuestionIndex}`}
            item={currentItem}
            currentQuestion={currentQuestionIndex}
            responses={currentResponse}
            onAnswer={handleAnswer}
            onBack={handleBack}
            onContinue={advanceQuestion}
          />
        )}

        {gameState === 'item-loop-end' && (
          <ItemLoopEndScreen
            key="loop-end"
            onContinue={handleContinueLoop}
            onFinish={handleFinish}
            itemsCompleted={allResponses.length}
          />
        )}

        {gameState === 'reflection' && allResponses.length > 0 && (
          <ReflectionScreen
            key="reflection"
            values={aggregateValues(allResponses)}
            persona={calculatePersona(aggregateValues(allResponses), allResponses)}
            responses={allResponses}
            onRestart={handleRestart}
            onExportJSON={handleExportJSON}
            onExportCSV={handleExportCSV}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
