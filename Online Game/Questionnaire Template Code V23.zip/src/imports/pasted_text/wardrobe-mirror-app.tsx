/**
 * ============================================================================
 * WARDROBE MIRROR - SINGLE FILE VERSION
 * ============================================================================
 * 
 * A mobile game exploring clothing decisions through an interactive card-swiping
 * interface. Features baseline calibration, branching narratives, and behavioral
 * archetype analysis for research on wardrobe behavior.
 * 
 * To use this file:
 * 1. Replace the contents of /src/app/App.tsx with this entire file
 * 2. Ensure these packages are installed:
 *    - motion
 *    - lucide-react
 *    - recharts
 *    - react
 * 
 * ============================================================================
 */

import React, { useState, useRef } from 'react';
import { motion, useMotionValue, useTransform } from 'motion/react';
import { 
  Compass, Heart, Wrench, DoorOpen, ArrowLeft, ArrowRight, Info,
  Download, FileDown, Share2, LayoutDashboard, Sparkles,
  TrendingUp, TrendingDown, Minus, X, Check, Copy
} from 'lucide-react';
import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  PolarRadiusAxis
} from 'recharts';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface ValueMeters {
  social: number;
  emotional: number;
  functional: number;
  inflowOutflow: number;
}

type ValueType = keyof ValueMeters;
type ValueLevel = 'low' | 'moderate' | 'high';
type GameState = 'baseline' | 'intro' | 'playing' | 'reflection';

interface GameChoice {
  scenarioId: string;
  stepId: string;
  scenarioPrompt: string;
  choice: 'a' | 'b';
  choiceText: string;
  timestamp: string;
  valuesAfter: ValueMeters;
}

interface GameData {
  sessionId: string;
  timestamp: string;
  totalScenarios: number;
  completedScenarios: number;
  finalValues: ValueMeters;
  choices: GameChoice[];
  persona?: string;
}

interface ScenarioStep {
  id: string;
  garmentIcon: string;
  prompt: string;
  choiceA: string;
  choiceB: string;
  insight?: string;
  effects: {
    a: Partial<ValueMeters>;
    b: Partial<ValueMeters>;
  };
  nextStep: {
    a: string | null;
    b: string | null;
  };
}

interface BranchingScenario {
  id: string;
  title: string;
  startStepId: string;
  steps: Record<string, ScenarioStep>;
}

interface BaselineResponses {
  wardrobeSize: 'minimal' | 'moderate' | 'extensive';
  shoppingFrequency: 'rarely' | 'occasionally' | 'frequently';
  disposalHabit: 'rarely' | 'periodically' | 'regularly';
  primaryDriver: 'function' | 'emotion' | 'social';
}

interface WardrobeArchetype {
  id: string;
  name: string;
  icon: string;
  tagline: string;
  description: string;
  acquisitionDrivers: string[];
  retentionPatterns: string[];
  disposalTriggers: string[];
  flowRate: 'Very Low' | 'Low' | 'Moderate' | 'High' | 'Very High';
  researchNotes: string;
  valueProfile: {
    social: ValueLevel;
    emotional: ValueLevel;
    functional: ValueLevel;
    inflowOutflow: ValueLevel;
  };
}

interface Persona {
  name: string;
  poeticDescription: string;
  iconType: 'sentimental' | 'utility' | 'trend' | 'conscious' | 'balanced';
  insight: string;
  researchProfile: {
    acquisitionDriver: string;
    retentionPattern: string;
    disposalTrigger: string;
    flowRate: 'low' | 'moderate' | 'high';
    primaryValue: string;
  };
}

// ============================================================================
// CONSTANTS & CONFIGURATION
// ============================================================================

const COLORS = {
  bone: '#f5f1e8',
  charcoal: '#1e293b',
  sage: '#8a9a5b',
  gold: '#d4af37',
  goldBright: '#f4d03f',
  darkGreen: '#1a2e1a',
};

const DEFAULT_VALUES: ValueMeters = {
  social: 50,
  emotional: 50,
  functional: 50,
  inflowOutflow: 50,
};

const VALUE_CONSTRAINTS = {
  min: 0,
  max: 100,
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

// Haptics
const haptics = {
  light: () => { if ('vibrate' in navigator) navigator.vibrate(10); },
  medium: () => { if ('vibrate' in navigator) navigator.vibrate(20); },
  success: () => { if ('vibrate' in navigator) navigator.vibrate([10, 50, 10]); },
  error: () => { if ('vibrate' in navigator) navigator.vibrate([20, 30, 20]); },
  complete: () => { if ('vibrate' in navigator) navigator.vibrate([30, 100, 30, 100, 50]); },
};

// Value manipulation
function clampValue(value: number): number {
  return Math.max(VALUE_CONSTRAINTS.min, Math.min(VALUE_CONSTRAINTS.max, value));
}

function applyEffects(currentValues: ValueMeters, effects: Partial<ValueMeters>): ValueMeters {
  return {
    social: clampValue(currentValues.social + (effects.social || 0)),
    emotional: clampValue(currentValues.emotional + (effects.emotional || 0)),
    functional: clampValue(currentValues.functional + (effects.functional || 0)),
    inflowOutflow: clampValue(currentValues.inflowOutflow + (effects.inflowOutflow || 0)),
  };
}

// Data export
function generateSessionId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function exportGameData(data: GameData): void {
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `wardrobe-mirror-session-${data.sessionId}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function exportCSV(data: GameData): void {
  const headers = [
    'Session ID', 'Timestamp', 'Scenario ID', 'Scenario Prompt', 'Choice Direction',
    'Choice Text', 'Social Value', 'Emotional Value', 'Functional Value', 'Inflow/Outflow Value',
  ];
  const rows = data.choices.map((choice) => [
    data.sessionId, choice.timestamp, choice.scenarioId, `"${choice.scenarioPrompt}"`,
    choice.choice, `"${choice.choiceText}"`, choice.valuesAfter.social,
    choice.valuesAfter.emotional, choice.valuesAfter.functional, choice.valuesAfter.inflowOutflow,
  ]);
  const csvContent = [headers, ...rows].map((row) => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `wardrobe-mirror-session-${data.sessionId}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Baseline calculation
function calculateBaselineValues(responses: BaselineResponses): ValueMeters {
  let values: ValueMeters;
  
  switch (responses.wardrobeSize) {
    case 'minimal':
      values = { functional: 70, social: 30, emotional: 50, inflowOutflow: 20 };
      break;
    case 'moderate':
      values = { functional: 50, social: 50, emotional: 50, inflowOutflow: 50 };
      break;
    case 'extensive':
      values = { functional: 40, social: 70, emotional: 60, inflowOutflow: 80 };
      break;
    default:
      values = { functional: 50, social: 50, emotional: 50, inflowOutflow: 50 };
  }

  switch (responses.disposalHabit) {
    case 'rarely':
      values.emotional += 15;
      values.functional += 10;
      values.inflowOutflow -= 15;
      break;
    case 'periodically':
      values.emotional += 10;
      values.functional -= 10;
      values.inflowOutflow -= 5;
      break;
    case 'regularly':
      values.social += 10;
      values.functional += 5;
      values.inflowOutflow += 20;
      values.emotional -= 10;
      break;
  }

  switch (responses.primaryDriver) {
    case 'function':
      values.functional += 10;
      values.emotional -= 5;
      values.social -= 5;
      break;
    case 'emotion':
      values.emotional += 10;
      values.functional -= 5;
      values.inflowOutflow -= 10;
      break;
    case 'social':
      values.social += 10;
      values.functional -= 5;
      values.inflowOutflow += 5;
      break;
  }

  switch (responses.shoppingFrequency) {
    case 'rarely':
      values.inflowOutflow -= 10;
      values.functional += 5;
      values.emotional += 5;
      break;
    case 'frequently':
      values.inflowOutflow += 15;
      values.social += 10;
      values.emotional -= 5;
      break;
  }

  return {
    social: Math.max(0, Math.min(100, values.social)),
    emotional: Math.max(0, Math.min(100, values.emotional)),
    functional: Math.max(0, Math.min(100, values.functional)),
    inflowOutflow: Math.max(0, Math.min(100, values.inflowOutflow)),
  };
}

function calculateDelta(baseline: ValueMeters, final: ValueMeters): ValueMeters {
  return {
    social: final.social - baseline.social,
    emotional: final.emotional - baseline.emotional,
    functional: final.functional - baseline.functional,
    inflowOutflow: final.inflowOutflow - baseline.inflowOutflow,
  };
}

// Persona calculation
function calculatePersona(finalValues: ValueMeters): Persona {
  const { emotional, social, functional, inflowOutflow } = finalValues;

  if (emotional > 70 && inflowOutflow < 40) {
    return {
      name: 'The Memory Keeper',
      poeticDescription: 'Every garment is a vessel for memory. You hold onto pieces not for their utility or appearance, but for the moments they represent. Your wardrobe is an archive of experiences, relationships, and chapters of your life.',
      iconType: 'sentimental',
      insight: 'Your attachment creates meaning, but abundance can obscure treasures. What if memories lived in you, not just in fabric?',
      researchProfile: {
        acquisitionDriver: 'Emotional resonance, gift-giving, milestone events',
        retentionPattern: 'Keeps items indefinitely due to sentimental attachment',
        disposalTrigger: 'Extreme deterioration or forced space constraints',
        flowRate: 'low',
        primaryValue: 'Emotional attachment and memory preservation',
      },
    };
  }

  if (social > 70 && inflowOutflow > 60) {
    return {
      name: 'The Social Chameleon',
      poeticDescription: 'Clothing is your social language. You acquire, adapt, and evolve with cultural currents, using fashion to navigate social landscapes. Your wardrobe flows rapidly—bringing in new pieces to match occasions and trends.',
      iconType: 'trend',
      insight: 'Your wardrobe speaks to the world with fluency. But ask: are you dressing for connection, or for constant validation?',
      researchProfile: {
        acquisitionDriver: 'Social events, trends, peer influence, identity expression',
        retentionPattern: 'Keeps items only while socially relevant',
        disposalTrigger: 'Social obsolescence',
        flowRate: 'high',
        primaryValue: 'Social identity and external perception',
      },
    };
  }

  if (functional > 70 && emotional < 40) {
    return {
      name: 'The Functional Minimalist',
      poeticDescription: 'Purpose guides every choice. You view clothing as tools that serve specific functions. Your wardrobe is lean, intentional, and performance-based. When something no longer serves, you replace it efficiently.',
      iconType: 'utility',
      insight: 'Your clarity is admirable. But consider: does pure function leave room for joy or self-expression?',
      researchProfile: {
        acquisitionDriver: 'Need-based replacement, specific functional requirements',
        retentionPattern: 'Keeps only what is actively used and performs well',
        disposalTrigger: 'Functional failure',
        flowRate: 'moderate',
        primaryValue: 'Practical utility and performance',
      },
    };
  }

  if (inflowOutflow > 70 && functional > 50 && emotional < 60) {
    return {
      name: 'The Conscious Curator',
      poeticDescription: 'You understand the lifecycle of garments. Your wardrobe flows with intention—you acquire thoughtfully and release gracefully. Circulation, not accumulation, is your philosophy.',
      iconType: 'conscious',
      insight: 'Your awareness of cycles is profound. Does constant flow create freedom, or prevent deeper connection?',
      researchProfile: {
        acquisitionDriver: 'Intentional need, ethical sourcing, quality over quantity',
        retentionPattern: 'Keeps items while useful, cycles out unused pieces',
        disposalTrigger: 'Conscious curation',
        flowRate: 'high',
        primaryValue: 'Mindful consumption and responsible stewardship',
      },
    };
  }

  const maxValue = Math.max(emotional, social, functional, inflowOutflow);
  if (maxValue === emotional) {
    return {
      name: 'The Memory Keeper',
      poeticDescription: 'Emotional attachment guides your wardrobe. You hold onto pieces for the stories they carry.',
      iconType: 'sentimental',
      insight: 'Your wardrobe holds your history. Which stories still serve you?',
      researchProfile: {
        acquisitionDriver: 'Emotional resonance',
        retentionPattern: 'Sentimental attachment',
        disposalTrigger: 'Rarely disposes',
        flowRate: 'low',
        primaryValue: 'Emotional attachment',
      },
    };
  }

  return {
    name: 'The Harmonist',
    poeticDescription: 'No single value dominates. You hold space for sentiment, social awareness, and function in balance.',
    iconType: 'balanced',
    insight: 'Your equilibrium is rare. Does balance reflect contentment, or absence of conviction?',
    researchProfile: {
      acquisitionDriver: 'Mixed motivations',
      retentionPattern: 'Varied reasons',
      disposalTrigger: 'Case-by-case decisions',
      flowRate: 'moderate',
      primaryValue: 'Multi-dimensional balance',
    },
  };
}

// Archetype definitions
const wardrobeArchetypes: WardrobeArchetype[] = [
  {
    id: 'memory-keeper',
    name: 'Memory Keeper',
    icon: '📖',
    tagline: 'Every garment tells a story',
    description: 'You form deep emotional bonds with clothing, viewing garments as memory vessels. Low acquisition but extremely high retention driven by sentiment.',
    acquisitionDrivers: ['Sentimental occasions', 'Gifts from relationships', 'Items tied to memories'],
    retentionPatterns: ['Intense emotional attachment', 'Story-based significance', 'Difficulty discarding'],
    disposalTriggers: ['Severe physical destruction', 'Rarely discards', 'Prefers repair'],
    flowRate: 'Very Low',
    researchNotes: 'High emotional attachment with minimal flow. Sustainable through extended lifespan but may accumulate excess.',
    valueProfile: { social: 'low', emotional: 'high', functional: 'low', inflowOutflow: 'low' },
  },
  {
    id: 'social-chameleon',
    name: 'Social Chameleon',
    icon: '🎭',
    tagline: 'Fashion adapts to every occasion',
    description: 'You use clothing strategically to navigate social contexts. Disposal triggered by social obsolescence rather than physical condition.',
    acquisitionDrivers: ['Social events', 'Professional expectations', 'Trend cycles'],
    retentionPatterns: ['Event-specific categorization', 'Social documentation anxiety', 'Context-dependent value'],
    disposalTriggers: ['Item "too photographed"', 'Social trends shift', 'No longer fits image'],
    flowRate: 'High',
    researchNotes: 'High social value drives rapid turnover. Vulnerable to fast fashion cycles.',
    valueProfile: { social: 'high', emotional: 'low', functional: 'moderate', inflowOutflow: 'high' },
  },
  {
    id: 'functional-minimalist',
    name: 'Functional Minimalist',
    icon: '⚙️',
    tagline: 'Purpose over aesthetics',
    description: 'You prioritize utility, durability, and versatility. Each item must demonstrate clear functional value to earn space.',
    acquisitionDrivers: ['Demonstrated functional gap', 'Superior quality', 'Multi-context versatility'],
    retentionPatterns: ['Performance-based evaluation', 'Regular utility audits', 'Wear-frequency tracking'],
    disposalTriggers: ['Loss of functional performance', 'Better alternative available', 'Consistent non-use'],
    flowRate: 'Low',
    researchNotes: 'Functional value dominates. Low inflow reflects intentional acquisition. Minimal social/emotional influence.',
    valueProfile: { social: 'low', emotional: 'low', functional: 'high', inflowOutflow: 'low' },
  },
  {
    id: 'conscious-curator',
    name: 'Conscious Curator',
    icon: '🌱',
    tagline: 'Mindful choices, lasting impact',
    description: 'You balance emotional connection, practical function, and social awareness through sustainability and ethics.',
    acquisitionDrivers: ['Ethical production', 'Long-term assessment', 'Environmental impact'],
    retentionPatterns: ['Active repair', 'Seasonal rotation', 'Circular economy participation'],
    disposalTriggers: ['Careful rehoming', 'Recycling/upcycling first', 'Only when beyond repair'],
    flowRate: 'Low',
    researchNotes: 'Balanced value profile. Low flow indicates intentional consumption with sustainability consciousness.',
    valueProfile: { social: 'moderate', emotional: 'moderate', functional: 'moderate', inflowOutflow: 'low' },
  },
  {
    id: 'aspirational-accumulator',
    name: 'Aspirational Accumulator',
    icon: '✨',
    tagline: "Building tomorrow's wardrobe today",
    description: 'You acquire for imagined futures and idealized self-versions. High inflow meets low outflow, resulting in accumulation.',
    acquisitionDrivers: ['Imagined scenarios', 'Aspirational identity', 'Promotional triggers'],
    retentionPatterns: ['Large unworn collection', '"Someday" justification', 'Tags-on retention'],
    disposalTriggers: ['Extreme space constraints', 'Expired aspirational timeframe', 'Crisis-driven purging'],
    flowRate: 'Very High',
    researchNotes: 'Very high inflow with very low outflow creates wardrobe bloat. Highly vulnerable to marketing.',
    valueProfile: { social: 'high', emotional: 'moderate', functional: 'low', inflowOutflow: 'high' },
  },
];

function determineArchetype(values: ValueMeters): WardrobeArchetype {
  const categorize = (value: number): ValueLevel => {
    if (value < 35) return 'low';
    if (value > 65) return 'high';
    return 'moderate';
  };

  const userProfile = {
    social: categorize(values.social),
    emotional: categorize(values.emotional),
    functional: categorize(values.functional),
    inflowOutflow: categorize(values.inflowOutflow),
  };

  const scores = wardrobeArchetypes.map((archetype) => {
    let score = 0;
    const weights = { social: 2.5, emotional: 2.5, functional: 2.5, inflowOutflow: 4.0 };

    for (const key of ['social', 'emotional', 'functional', 'inflowOutflow'] as const) {
      if (userProfile[key] === archetype.valueProfile[key]) {
        score += 10 * weights[key];
      } else {
        const distance = Math.abs(
          (['low', 'moderate', 'high'].indexOf(userProfile[key])) -
          (['low', 'moderate', 'high'].indexOf(archetype.valueProfile[key]))
        );
        if (distance === 1) score += 3 * weights[key];
      }
    }

    return { archetype, score };
  });

  scores.sort((a, b) => b.score - a.score);
  return scores[0].archetype;
}

// ============================================================================
// SCENARIO DATA
// ============================================================================

const branchingScenarios: BranchingScenario[] = [
  // Scenario 1: Engagement Party
  {
    id: 'engagement-party',
    title: 'The Engagement Party',
    startStepId: 'ep-1',
    steps: {
      'ep-1': {
        id: 'ep-1',
        garmentIcon: '💍',
        prompt: "You've been invited to an engagement party this weekend. When deciding what to wear, you...",
        choiceA: 'Look through your wardrobe',
        choiceB: 'Browse online shops',
        insight: '60% of wardrobe items are underutilized. Checking existing pieces first can reveal forgotten treasures.',
        effects: { a: { functional: 8, emotional: 4, inflowOutflow: -6 }, b: { social: 8, inflowOutflow: 10, functional: -3 } },
        nextStep: { a: 'ep-2a', b: 'ep-2b' },
      },
      'ep-2a': {
        id: 'ep-2a',
        garmentIcon: '👗',
        prompt: "You find a suit/dress that would work perfectly, but you've worn it to a few events recently...",
        choiceA: 'Wear it anyway',
        choiceB: 'Buy something new instead',
        insight: 'The fear of "outfit repeating" is a modern anxiety driven by social media documentation.',
        effects: { a: { functional: 10, emotional: 6, social: -8, inflowOutflow: -8 }, b: { social: 10, inflowOutflow: 14, emotional: -4 } },
        nextStep: { a: 'ep-3a', b: 'ep-3b' },
      },
      'ep-3a': {
        id: 'ep-3a',
        garmentIcon: '👀',
        prompt: 'At the party, you notice that people...',
        choiceA: 'Seem to recognize the outfit',
        choiceB: "Don't seem to notice at all",
        insight: 'We overestimate how much others notice our clothing—the "spotlight effect" in action.',
        effects: { a: { social: -10, emotional: -8, functional: 4 }, b: { social: 4, emotional: 8, functional: 6 } },
        nextStep: { a: 'ep-4-all', b: 'ep-4-all' },
      },
      'ep-2b': {
        id: 'ep-2b',
        garmentIcon: '🛍️',
        prompt: 'While browsing, you find something you like. It's available in two versions...',
        choiceA: 'Buy the expensive one',
        choiceB: 'Buy the affordable one',
        insight: "Price doesn't always correlate with quality. Fast fashion's low prices encourage disposal.",
        effects: { a: { social: 12, emotional: 10, inflowOutflow: 8, functional: 6 }, b: { social: 6, inflowOutflow: 15, functional: -8, emotional: -4 } },
        nextStep: { a: 'ep-3b', b: 'ep-3b' },
      },
      'ep-3b': {
        id: 'ep-3b',
        garmentIcon: '✨',
        prompt: 'At the party wearing your new outfit, people...',
        choiceA: 'Compliment you on it',
        choiceB: "Don't really notice",
        insight: 'New clothing activates reward centers in the brain, creating dopamine-driven purchase cycles.',
        effects: { a: { social: 12, emotional: 10, functional: 2 }, b: { social: -6, emotional: -8, functional: 4 } },
        nextStep: { a: 'ep-4-all', b: 'ep-4-all' },
      },
      'ep-4-all': {
        id: 'ep-4-all',
        garmentIcon: '🍷',
        prompt: 'Someone accidentally spills red wine on your outfit. When you get home, you...',
        choiceA: 'Try to wash it out',
        choiceB: 'Throw it away',
        insight: 'Fast fashion has normalized disposal over repair. Most stains are removable with proper care.',
        effects: { a: { functional: 12, emotional: 6, inflowOutflow: -10 }, b: { inflowOutflow: 18, functional: -12, emotional: -10 } },
        nextStep: { a: 'ep-5a', b: null },
      },
      'ep-5a': {
        id: 'ep-5a',
        garmentIcon: '🧼',
        prompt: 'After washing, the stain is still faintly visible. You...',
        choiceA: 'Research other cleaning methods',
        choiceB: 'Give up and throw it away',
        insight: 'Garment care knowledge has declined generationally. Our grandparents had stain-removal expertise.',
        effects: { a: { functional: 14, emotional: 8, inflowOutflow: -12 }, b: { inflowOutflow: 18, functional: -10, emotional: -12 } },
        nextStep: { a: null, b: null },
      },
    },
  },
  // Scenario 2: Gifted Hoodie
  {
    id: 'gifted-hoodie',
    title: 'The Unworn Gift',
    startStepId: 'gh-1',
    steps: {
      'gh-1': {
        id: 'gh-1',
        garmentIcon: '🎁',
        prompt: "The next morning, you notice a hoodie a friend gave you last year. You've never worn it. You decide to...",
        choiceA: 'Keep it in your wardrobe',
        choiceB: 'Let it go',
        insight: 'Gifted clothing creates emotional obligation. 40% of unworn items are gifts kept out of guilt.',
        effects: { a: { emotional: 12, inflowOutflow: -12, functional: -10 }, b: { functional: 10, inflowOutflow: 14, emotional: -14 } },
        nextStep: { a: null, b: null },
      },
    },
  },
  // Scenario 3: Broken Zipper
  {
    id: 'broken-zipper',
    title: 'The Broken Zipper',
    startStepId: 'bz-1',
    steps: {
      'bz-1': {
        id: 'bz-1',
        garmentIcon: '🧥',
        prompt: 'You put on your everyday sweater and pull up the zipper. It breaks.',
        choiceA: 'Throw it in the bin',
        choiceB: 'See if it can be saved',
        insight: 'Repair extends garment lifespan by 2+ years. But repair infrastructure has declined as fast fashion rose.',
        effects: { a: { inflowOutflow: 16, functional: -12, emotional: -10 }, b: { functional: 8, emotional: 8, inflowOutflow: -6 } },
        nextStep: { a: 'bz-2a', b: 'bz-2b' },
      },
      'bz-2a': {
        id: 'bz-2a',
        garmentIcon: '👔',
        prompt: 'You grab a different sweater. At the office, it looks a bit dated compared to colleagues.',
        choiceA: "It doesn't bother you",
        choiceB: 'Time to update your wardrobe',
        insight: 'Workplace fashion norms create pressure to maintain appearances despite functional adequacy.',
        effects: { a: { functional: 10, social: -12, emotional: 6 }, b: { social: 12, inflowOutflow: 8, functional: -4 } },
        nextStep: { a: null, b: 'bz-3a-buy' },
      },
      'bz-3a-buy': {
        id: 'bz-3a-buy',
        garmentIcon: '🛒',
        prompt: 'You find a nice new sweater. At checkout, there's a "Buy 2, Get 1 Free" promotion.',
        choiceA: 'Take the deal',
        choiceB: 'Just buy the one',
        insight: 'Multi-buy promotions encourage overconsumption. Retailers profit regardless of whether items are worn.',
        effects: { a: { inflowOutflow: 20, social: 8, functional: -10 }, b: { functional: 10, inflowOutflow: 8, emotional: 6 } },
        nextStep: { a: null, b: null },
      },
      'bz-2b': {
        id: 'bz-2b',
        garmentIcon: '🤔',
        prompt: 'Looking at the broken sweater, you decide to...',
        choiceA: 'Get it professionally repaired',
        choiceB: 'Keep it for wearing at home',
        insight: 'Downgrading garments from "public" to "private" extends life but creates psychological bloat.',
        effects: { a: { functional: 10, emotional: 8, inflowOutflow: -10 }, b: { functional: 6, emotional: 10, social: -8, inflowOutflow: -6 } },
        nextStep: { a: 'bz-3b-repair', b: null },
      },
      'bz-3b-repair': {
        id: 'bz-3b-repair',
        garmentIcon: '🧵',
        prompt: 'A local tailor can fix it. The repair would cost about half the price of buying new.',
        choiceA: 'Go ahead with the repair',
        choiceB: 'Buy a new one instead',
        insight: 'When repair costs approach new item prices, economic logic favors replacement—a structural problem.',
        effects: { a: { functional: 14, emotional: 10, inflowOutflow: -14, social: 4 }, b: { inflowOutflow: 12, functional: -6, emotional: -8 } },
        nextStep: { a: null, b: null },
      },
    },
  },
];

function getStepById(scenario: BranchingScenario, stepId: string): ScenarioStep | undefined {
  return scenario.steps[stepId];
}

// ============================================================================
// REACT COMPONENTS
// ============================================================================

// Value Meter Component
function ValueMeter({ type, value }: { type: ValueType; value: number }) {
  const config = {
    social: { icon: Compass, label: 'Social', color: '#d4af37' },
    emotional: { icon: Heart, label: 'Emotional', color: '#ec4899' },
    functional: { icon: Wrench, label: 'Functional', color: '#3b82f6' },
    inflowOutflow: { icon: DoorOpen, label: 'Flow', color: '#8a9a5b' },
  };

  const { icon: Icon, label, color } = config[type];

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-12 h-12">
        <svg className="w-12 h-12 -rotate-90" viewBox="0 0 48 48">
          <circle cx="24" cy="24" r="20" fill="none" stroke="rgba(245, 241, 232, 0.2)" strokeWidth="2" />
          <circle
            cx="24" cy="24" r="20" fill="none" stroke={color} strokeWidth="2"
            strokeDasharray={`${(value / 100) * 125.6} 125.6`} strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 4px ${color})` }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <Icon className="w-5 h-5" strokeWidth={1.5} style={{ color: '#f5f1e8' }} />
        </div>
      </div>
      <span
        className="text-[9px] tracking-widest uppercase font-light"
        style={{ fontFamily: 'Inter, sans-serif', color: 'rgba(245, 241, 232, 0.6)' }}
      >
        {label}
      </span>
    </div>
  );
}

// Game Card Component
function GameCard({ scenario, onSwipe, zIndex, isTop }: {
  scenario: ScenarioStep;
  onSwipe: (direction: 'left' | 'right') => void;
  zIndex: number;
  isTop: boolean;
}) {
  const [showInsight, setShowInsight] = useState(false);
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-8, 8]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0, 1, 1, 1, 0]);
  const leftOverlay = useTransform(x, [-150, -50, 0], [1, 0.6, 0]);
  const rightOverlay = useTransform(x, [0, 50, 150], [0, 0.6, 1]);

  const handleDragEnd = (_: any, info: any) => {
    if (info.offset.x > 120) {
      haptics.medium();
      onSwipe('right');
    } else if (info.offset.x < -120) {
      haptics.medium();
      onSwipe('left');
    }
  };

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center"
      style={{ x, rotate, opacity, zIndex, cursor: isTop ? 'grab' : 'default' }}
      drag={isTop ? 'x' : false}
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.7}
      onDragEnd={handleDragEnd}
      whileTap={{ cursor: 'grabbing' }}
    >
      <div
        className="w-[360px] h-[580px] rounded-3xl overflow-hidden relative"
        style={{
          background: 'linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(26, 46, 26, 0.95))',
          border: '1px solid rgba(245, 241, 232, 0.2)',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
        }}
      >
        {/* Swipe Overlays */}
        <motion.div
          className="absolute inset-0 flex items-center justify-center pointer-events-none z-10"
          style={{
            opacity: leftOverlay,
            background: 'linear-gradient(135deg, rgba(138, 154, 91, 0.95), rgba(106, 168, 79, 0.95))',
          }}
        >
          <div className="text-center px-8">
            <div className="text-5xl font-light mb-4" style={{ fontFamily: 'Georgia, serif', color: '#f5f1e8' }}>A.</div>
            <p className="text-lg" style={{ fontFamily: 'Inter, sans-serif', color: '#f5f1e8' }}>{scenario.choiceA}</p>
          </div>
        </motion.div>

        <motion.div
          className="absolute inset-0 flex items-center justify-center pointer-events-none z-10"
          style={{
            opacity: rightOverlay,
            background: 'linear-gradient(135deg, rgba(212, 175, 55, 0.95), rgba(244, 208, 63, 0.95))',
          }}
        >
          <div className="text-center px-8">
            <div className="text-5xl font-light mb-4" style={{ fontFamily: 'Georgia, serif', color: '#1a2e1a' }}>B.</div>
            <p className="text-lg" style={{ fontFamily: 'Inter, sans-serif', color: '#1a2e1a' }}>{scenario.choiceB}</p>
          </div>
        </motion.div>

        {/* Card Content */}
        <div className="relative h-full flex flex-col">
          <div
            className="h-[280px] flex items-center justify-center relative"
            style={{
              background: 'linear-gradient(to bottom, rgba(30, 41, 59, 0.4), rgba(26, 46, 26, 0.6))',
              borderBottom: '1px solid rgba(245, 241, 232, 0.1)',
            }}
          >
            <div className="text-8xl" style={{ filter: 'saturate(1.3) brightness(1.2)' }}>
              {scenario.garmentIcon}
            </div>

            <button
              onClick={() => {
                haptics.light();
                setShowInsight(!showInsight);
              }}
              className="absolute top-4 right-4 w-10 h-10 rounded-2xl flex items-center justify-center"
              style={{
                background: showInsight ? 'rgba(212, 175, 55, 0.3)' : 'rgba(255, 255, 255, 0.05)',
                border: showInsight ? '1px solid rgba(212, 175, 55, 0.6)' : '1px solid rgba(255, 255, 255, 0.2)',
                color: showInsight ? '#d4af37' : 'rgba(255, 255, 255, 0.6)',
              }}
            >
              <Info className="w-4 h-4" strokeWidth={1.5} />
            </button>
          </div>

          <div className="flex-1 p-8 flex flex-col justify-between">
            {!showInsight ? (
              <>
                <p className="text-lg leading-relaxed" style={{ fontFamily: 'Georgia, serif', color: '#f5f1e8' }}>
                  {scenario.prompt}
                </p>
                <div className="flex gap-3 pt-4">
                  <div className="flex-1 py-3 px-4 rounded-2xl" style={{ background: 'rgba(138, 154, 91, 0.2)', border: '1px solid rgba(138, 154, 91, 0.4)' }}>
                    <span className="text-xs" style={{ color: 'rgba(245, 241, 232, 0.8)' }}>A: {scenario.choiceA}</span>
                  </div>
                  <div className="flex-1 py-3 px-4 rounded-2xl" style={{ background: 'rgba(212, 175, 55, 0.2)', border: '1px solid rgba(212, 175, 55, 0.4)' }}>
                    <span className="text-xs" style={{ color: 'rgba(245, 241, 232, 0.8)' }}>B: {scenario.choiceB}</span>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full text-center">
                <div>
                  <div className="text-[10px] uppercase mb-4" style={{ color: '#d4af37' }}>Academic Insight</div>
                  <p className="text-sm italic" style={{ color: 'rgba(245, 241, 232, 0.8)' }}>"{scenario.insight}"</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// Baseline Questions Component
function BaselineQuestions({ onComplete }: { onComplete: (values: BaselineResponses) => void }) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const questions = [
    {
      id: 'wardrobeSize',
      question: 'How would you describe your current wardrobe size?',
      options: [
        { value: 'minimal', label: 'Minimal', description: 'I own only what I need and wear regularly' },
        { value: 'moderate', label: 'Moderate', description: 'I have a balanced selection with some variety' },
        { value: 'extensive', label: 'Extensive', description: 'I have many items, including pieces I rarely wear' },
      ],
    },
    {
      id: 'shoppingFrequency',
      question: 'How often do you acquire new clothing items?',
      options: [
        { value: 'rarely', label: 'Rarely', description: 'Only when I truly need to replace something' },
        { value: 'occasionally', label: 'Occasionally', description: 'A few times per season when I find something I like' },
        { value: 'frequently', label: 'Frequently', description: 'I enjoy shopping and add new items regularly' },
      ],
    },
    {
      id: 'disposalHabit',
      question: 'How often do you dispose of clothing items?',
      options: [
        { value: 'rarely', label: 'Rarely', description: 'I keep items for extended periods' },
        { value: 'periodically', label: 'Periodically', description: 'I review and dispose regularly' },
        { value: 'regularly', label: 'Regularly', description: 'I frequently clear out items' },
      ],
    },
    {
      id: 'primaryDriver',
      question: 'What primarily drives your clothing decisions?',
      options: [
        { value: 'function', label: 'Functionality', description: 'Comfort, durability, and practicality' },
        { value: 'emotion', label: 'Emotional Connection', description: 'How clothing makes me feel' },
        { value: 'social', label: 'Social Expression', description: 'How I'm perceived and expressing identity' },
      ],
    },
  ];

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleNext = () => {
    haptics.medium();
    const newAnswers = { ...answers, [currentQ.id]: selectedOption };
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(null);
    } else {
      const finalValues: BaselineResponses = {
        wardrobeSize: newAnswers['wardrobeSize'] as any || 'moderate',
        shoppingFrequency: newAnswers['shoppingFrequency'] as any || 'occasionally',
        disposalHabit: newAnswers['disposalHabit'] as any || 'periodically',
        primaryDriver: newAnswers['primaryDriver'] as any || 'function',
      };
      onComplete(finalValues);
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(135deg, #1e293b 0%, #1a2e1a 100%)' }}>
      <div className="relative z-10 pt-16 pb-8 px-6 text-center">
        <div className="max-w-md mx-auto space-y-6">
          <div className="flex items-center justify-center gap-3">
            <Sparkles className="w-6 h-6" style={{ color: '#d4af37' }} />
            <h1 className="text-3xl" style={{ fontFamily: 'Georgia, serif', color: '#f5f1e8' }}>Calibration</h1>
            <Sparkles className="w-6 h-6" style={{ color: '#d4af37' }} />
          </div>
          <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
            Set your baseline values to personalize your journey
          </p>
          <div className="pt-4">
            <div className="flex justify-between mb-3 text-xs" style={{ color: 'rgba(245, 241, 232, 0.5)' }}>
              <span>Question {currentQuestion + 1} of {questions.length}</span>
              <span style={{ color: '#d4af37' }}>{Math.round(progress)}%</span>
            </div>
            <div className="h-1 rounded-full" style={{ background: 'rgba(245, 241, 232, 0.1)' }}>
              <div className="h-full" style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #d4af37, #8a9a5b)' }} />
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 px-6 pb-12 flex items-center">
        <div className="max-w-md mx-auto w-full">
          <div className="rounded-3xl p-8 space-y-8" style={{ background: 'rgba(255, 255, 255, 0.05)', border: '1px solid rgba(245, 241, 232, 0.2)' }}>
            <h2 className="text-xl text-center" style={{ fontFamily: 'Georgia, serif', color: '#f5f1e8' }}>{currentQ.question}</h2>
            <div className="space-y-4">
              {currentQ.options.map(option => (
                <button
                  key={option.value}
                  onClick={() => {
                    setSelectedOption(option.value);
                    haptics.light();
                  }}
                  className="w-full text-left p-5 rounded-2xl"
                  style={{
                    background: selectedOption === option.value ? 'rgba(212, 175, 55, 0.3)' : 'rgba(255, 255, 255, 0.03)',
                    border: selectedOption === option.value ? '2px solid #d4af37' : '1px solid rgba(245, 241, 232, 0.15)',
                  }}
                >
                  <p style={{ fontFamily: 'Georgia, serif', color: selectedOption === option.value ? '#d4af37' : '#f5f1e8' }}>
                    {option.label}
                  </p>
                  <p className="text-xs mt-1" style={{ color: 'rgba(245, 241, 232, 0.6)' }}>{option.description}</p>
                </button>
              ))}
            </div>
            <button
              onClick={handleNext}
              disabled={!selectedOption}
              className="w-full py-4 rounded-full text-sm uppercase"
              style={{
                background: selectedOption ? 'linear-gradient(135deg, #d4af37, #f4d03f)' : 'rgba(245, 241, 232, 0.1)',
                color: selectedOption ? '#1a2e1a' : 'rgba(245, 241, 232, 0.3)',
                cursor: selectedOption ? 'pointer' : 'not-allowed',
                opacity: selectedOption ? 1 : 0.5,
              }}
            >
              {currentQuestion < questions.length - 1 ? 'Continue' : 'Complete'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Wardrobe Reflection Component
function WardrobeReflection({ values, baselineValues, gameData, onRestart, onExportJSON, onExportCSV }: {
  values: ValueMeters;
  baselineValues: ValueMeters;
  gameData: GameData;
  onRestart: () => void;
  onExportJSON: () => void;
  onExportCSV: () => void;
}) {
  const [activeView, setActiveView] = useState<'dashboard' | 'data'>('dashboard');
  const persona = calculatePersona(values);
  const archetype = determineArchetype(values);

  const radarData = [
    { dimension: 'Social', value: values.social, baseline: baselineValues.social },
    { dimension: 'Emotional', value: values.emotional, baseline: baselineValues.emotional },
    { dimension: 'Functional', value: values.functional, baseline: baselineValues.functional },
    { dimension: 'Flow', value: values.inflowOutflow, baseline: baselineValues.inflowOutflow },
  ];

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(135deg, #1e293b 0%, #1a2e1a 100%)' }}>
      <div className="pt-12 pb-6 text-center" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.1)' }}>
        <h1 className="text-2xl uppercase" style={{ fontFamily: 'Georgia, serif', color: 'white' }}>Wardrobe Reflection</h1>
        <p className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>Your value profile</p>
      </div>

      <div className="flex" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.1)' }}>
        <button
          onClick={() => setActiveView('dashboard')}
          className={`flex-1 py-4 text-xs uppercase ${activeView === 'dashboard' ? 'text-white border-b-2' : 'text-white/50'}`}
          style={activeView === 'dashboard' ? { borderColor: '#d4af37' } : {}}
        >
          <LayoutDashboard className="w-3 h-3 inline mr-2" />Dashboard
        </button>
        <button
          onClick={() => setActiveView('data')}
          className={`flex-1 py-4 text-xs uppercase ${activeView === 'data' ? 'text-white border-b-2' : 'text-white/50'}`}
          style={activeView === 'data' ? { borderColor: '#d4af37' } : {}}
        >
          <Download className="w-3 h-3 inline mr-2" />Data
        </button>
      </div>

      <div className="flex-1 overflow-y-auto py-12 px-6">
        <div className="max-w-md mx-auto">
          {activeView === 'dashboard' && (
            <div className="space-y-8">
              <div className="text-center p-8 rounded-2xl" style={{ background: 'rgba(255, 255, 255, 0.05)', border: '1px solid rgba(255, 255, 255, 0.18)' }}>
                <h2 className="text-3xl mb-4" style={{ fontFamily: 'Georgia, serif', color: 'white' }}>{persona.name}</h2>
                <p className="text-sm italic mb-6" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{persona.poeticDescription}</p>
                <div className="p-6 rounded-xl" style={{ background: 'rgba(212, 175, 55, 0.1)', border: '2px solid rgba(212, 175, 55, 0.3)' }}>
                  <div className="text-xs uppercase mb-3" style={{ color: '#d4af37' }}>Reflection Prompt</div>
                  <p className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{persona.insight}</p>
                </div>
              </div>

              <div className="p-6 rounded-2xl" style={{ background: 'rgba(255, 255, 255, 0.05)' }}>
                <h3 className="text-center mb-6" style={{ color: 'white' }}>Your Value Profile</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="rgba(255, 255, 255, 0.2)" />
                    <PolarAngleAxis dataKey="dimension" tick={{ fill: 'rgba(255, 255, 255, 0.7)', fontSize: 12 }} />
                    <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: 'rgba(255, 255, 255, 0.5)' }} />
                    <Radar name="Baseline" dataKey="baseline" stroke="#8a9a5b" fill="#8a9a5b" fillOpacity={0.2} />
                    <Radar name="Current" dataKey="value" stroke="#d4af37" fill="#d4af37" fillOpacity={0.5} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              <div className="p-6 rounded-2xl" style={{ background: 'rgba(212, 175, 55, 0.08)', border: '1px solid rgba(212, 175, 55, 0.25)' }}>
                <h3 className="text-base mb-4" style={{ fontFamily: 'Georgia, serif', color: 'white' }}>
                  Behavioral Profile: {archetype.name} {archetype.icon}
                </h3>
                <p className="text-sm mb-4" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{archetype.tagline}</p>
                <p className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>{archetype.description}</p>
              </div>
            </div>
          )}

          {activeView === 'data' && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-lg mb-2" style={{ color: 'white' }}>Research Data Export</h2>
                <p className="text-sm" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>Download your session data</p>
              </div>

              <button onClick={onExportJSON} className="w-full p-6 rounded-2xl" style={{ background: 'rgba(255, 255, 255, 0.05)', border: '1px solid rgba(255, 255, 255, 0.18)' }}>
                <div className="flex items-center justify-between">
                  <div className="text-left">
                    <h3 className="text-sm mb-1" style={{ color: 'white' }}>Export as JSON</h3>
                    <p className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>Complete session data</p>
                  </div>
                  <FileDown className="w-5 h-5" style={{ color: '#d4af37' }} />
                </div>
              </button>

              <button onClick={onExportCSV} className="w-full p-6 rounded-2xl" style={{ background: 'rgba(255, 255, 255, 0.05)', border: '1px solid rgba(255, 255, 255, 0.18)' }}>
                <div className="flex items-center justify-between">
                  <div className="text-left">
                    <h3 className="text-sm mb-1" style={{ color: 'white' }}>Export as CSV</h3>
                    <p className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>Spreadsheet format</p>
                  </div>
                  <FileDown className="w-5 h-5" style={{ color: '#d4af37' }} />
                </div>
              </button>

              <div className="p-6 rounded-2xl" style={{ background: 'rgba(255, 255, 255, 0.05)' }}>
                <h3 className="text-sm mb-4" style={{ color: 'white' }}>Session Summary</h3>
                <div className="space-y-2 text-xs" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>
                  <div className="flex justify-between">
                    <span>Session ID:</span>
                    <span className="font-mono">{gameData.sessionId.substring(0, 12)}...</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Scenarios:</span>
                    <span>{gameData.completedScenarios}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Persona:</span>
                    <span style={{ color: '#d4af37' }}>{persona.name}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-6" style={{ borderTop: '1px solid rgba(255, 255, 255, 0.1)' }}>
        <button
          onClick={() => {
            haptics.success();
            onRestart();
          }}
          className="w-full py-4 rounded-xl text-sm uppercase"
          style={{
            background: 'linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(138, 154, 91, 0.2))',
            border: '1px solid rgba(212, 175, 55, 0.4)',
            color: '#d4af37',
          }}
        >
          New Reflection
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// MAIN APP COMPONENT
// ============================================================================

export default function App() {
  const [gameState, setGameState] = useState<GameState>('baseline');
  const [sessionId] = useState(generateSessionId());
  const [sessionStartTime] = useState(new Date().toISOString());
  const [values, setValues] = useState<ValueMeters>(DEFAULT_VALUES);
  const [baselineValues, setBaselineValues] = useState<ValueMeters>(DEFAULT_VALUES);
  const [currentScenarioIndex, setCurrentScenarioIndex] = useState(0);
  const [currentStepId, setCurrentStepId] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<ScenarioStep | null>(null);
  const [choices, setChoices] = useState<Array<GameChoice>>([]);
  const [baselineResponses, setBaselineResponses] = useState<BaselineResponses | null>(null);

  const handleBaselineComplete = (responses: BaselineResponses) => {
    setBaselineResponses(responses);
    const calibratedValues = calculateBaselineValues(responses);
    setValues(calibratedValues);
    setBaselineValues(calibratedValues);
    setGameState('intro');
  };

  const startGame = () => {
    haptics.light();
    const firstScenario = branchingScenarios[0];
    const firstStep = getStepById(firstScenario, firstScenario.startStepId);
    setCurrentScenarioIndex(0);
    setCurrentStepId(firstScenario.startStepId);
    setCurrentStep(firstStep || null);
    setGameState('playing');
  };

  const handleSwipe = (direction: 'left' | 'right') => {
    if (!currentStep) return;
    
    const choice = direction === 'left' ? 'a' : 'b';
    const effects = currentStep.effects[choice];
    const choiceText = choice === 'a' ? currentStep.choiceA : currentStep.choiceB;
    const nextStepId = currentStep.nextStep[choice];

    const newValues: ValueMeters = applyEffects(values, effects);
    setValues(newValues);

    setChoices((prev) => [
      ...prev,
      {
        scenarioId: branchingScenarios[currentScenarioIndex].id,
        stepId: currentStep.id,
        scenarioPrompt: currentStep.prompt,
        choice,
        choiceText,
        timestamp: new Date().toISOString(),
        valuesAfter: newValues,
      },
    ]);

    setTimeout(() => {
      if (nextStepId === null) {
        const nextScenarioIndex = currentScenarioIndex + 1;
        if (nextScenarioIndex >= branchingScenarios.length) {
          haptics.complete();
          setGameState('reflection');
        } else {
          const nextScenario = branchingScenarios[nextScenarioIndex];
          const nextStep = getStepById(nextScenario, nextScenario.startStepId);
          setCurrentScenarioIndex(nextScenarioIndex);
          setCurrentStepId(nextScenario.startStepId);
          setCurrentStep(nextStep || null);
        }
      } else {
        const currentScenario = branchingScenarios[currentScenarioIndex];
        const nextStep = getStepById(currentScenario, nextStepId);
        setCurrentStepId(nextStepId);
        setCurrentStep(nextStep || null);
      }
    }, 300);
  };

  const handleExportJSON = () => {
    const gameData: GameData = {
      sessionId,
      timestamp: sessionStartTime,
      totalScenarios: branchingScenarios.length,
      completedScenarios: choices.length,
      finalValues: values,
      choices,
    };
    exportGameData(gameData);
  };

  const handleExportCSV = () => {
    const gameData: GameData = {
      sessionId,
      timestamp: sessionStartTime,
      totalScenarios: branchingScenarios.length,
      completedScenarios: choices.length,
      finalValues: values,
      choices,
    };
    exportCSV(gameData);
  };

  const handleRestart = () => {
    setValues(DEFAULT_VALUES);
    setBaselineValues(DEFAULT_VALUES);
    setCurrentScenarioIndex(0);
    setCurrentStepId(null);
    setCurrentStep(null);
    setChoices([]);
    setBaselineResponses(null);
    setGameState('baseline');
  };

  if (gameState === 'reflection') {
    const gameData: GameData = {
      sessionId,
      timestamp: sessionStartTime,
      totalScenarios: branchingScenarios.length,
      completedScenarios: choices.length,
      finalValues: values,
      choices,
    };

    return (
      <WardrobeReflection
        values={values}
        baselineValues={baselineValues}
        gameData={gameData}
        onRestart={handleRestart}
        onExportJSON={handleExportJSON}
        onExportCSV={handleExportCSV}
      />
    );
  }

  if (gameState === 'intro') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6" style={{ background: 'linear-gradient(135deg, #1e293b 0%, #1a2e1a 100%)' }}>
        <div className="max-w-md w-full space-y-12 text-center">
          <div className="space-y-6">
            <h1 className="text-5xl" style={{ fontFamily: 'Georgia, serif', color: '#f5f1e8' }}>
              The Wardrobe<br />Mirror
            </h1>
            <div className="w-20 h-px mx-auto" style={{ background: 'linear-gradient(90deg, transparent, #d4af37 50%, transparent)' }} />
            <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
              A reflective game exploring the values that shape your relationship with clothing
            </p>
          </div>

          <div className="rounded-3xl p-8 text-left space-y-6" style={{ background: 'rgba(255, 255, 255, 0.05)', border: '1px solid rgba(245, 241, 232, 0.2)' }}>
            <h2 className="text-xl" style={{ fontFamily: 'Georgia, serif', color: '#f5f1e8' }}>How to Play</h2>
            <div className="space-y-4 text-sm">
              <p style={{ color: 'rgba(245, 241, 232, 0.8)' }}>1. Navigate real-life scenarios about clothing choices</p>
              <p style={{ color: 'rgba(245, 241, 232, 0.8)' }}>2. Swipe left or right to make your choice</p>
              <p style={{ color: 'rgba(245, 241, 232, 0.8)' }}>3. Discover how your values shift based on decisions</p>
              <p style={{ color: 'rgba(245, 241, 232, 0.8)' }}>4. Tap the insight button for research context</p>
            </div>
          </div>

          <button
            onClick={startGame}
            className="w-full py-4 rounded-full text-sm uppercase"
            style={{
              background: 'linear-gradient(135deg, #d4af37, #f4d03f)',
              color: '#1a2e1a',
              boxShadow: '0 4px 16px rgba(212, 175, 55, 0.4)',
            }}
          >
            Begin Reflection
          </button>
        </div>
      </div>
    );
  }

  if (gameState === 'baseline') {
    return <BaselineQuestions onComplete={handleBaselineComplete} />;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(135deg, #1e293b 0%, #1a2e1a 100%)' }}>
      <div className="pt-8 pb-6 px-6" style={{ borderBottom: '1px solid rgba(245, 241, 232, 0.1)' }}>
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-lg" style={{ fontFamily: 'Georgia, serif', color: '#f5f1e8' }}>The Wardrobe Mirror</h1>
            <span className="text-xs" style={{ color: 'rgba(245, 241, 232, 0.6)' }}>
              {currentScenarioIndex + 1} / {branchingScenarios.length}
            </span>
          </div>
          <div className="h-1 rounded-full" style={{ background: 'rgba(245, 241, 232, 0.1)' }}>
            <div className="h-full" style={{ width: `${((currentScenarioIndex + 1) / branchingScenarios.length) * 100}%`, background: 'linear-gradient(90deg, #d4af37, #8a9a5b)' }} />
          </div>
        </div>
      </div>

      <div className="py-6 px-6">
        <div className="max-w-md mx-auto flex justify-between">
          <ValueMeter type="social" value={values.social} />
          <ValueMeter type="emotional" value={values.emotional} />
          <ValueMeter type="functional" value={values.functional} />
          <ValueMeter type="inflowOutflow" value={values.inflowOutflow} />
        </div>
      </div>

      <div className="flex-1 px-6 py-8">
        <div className="max-w-md mx-auto h-[580px] relative">
          {currentStep && (
            <GameCard
              key={currentStep.id}
              scenario={currentStep}
              onSwipe={handleSwipe}
              zIndex={1}
              isTop={true}
            />
          )}
        </div>
      </div>

      <div className="pb-8 px-6" style={{ borderTop: '1px solid rgba(245, 241, 232, 0.1)' }}>
        <div className="max-w-md mx-auto pt-6 flex items-center justify-between">
          <div className="flex items-center gap-3" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'rgba(138, 154, 91, 0.2)', border: '1px solid rgba(138, 154, 91, 0.4)' }}>
              <ArrowLeft className="w-5 h-5" style={{ color: '#8a9a5b' }} />
            </div>
            <span className="text-xs uppercase">Swipe Left: A</span>
          </div>
          <div className="flex items-center gap-3" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
            <span className="text-xs uppercase">Swipe Right: B</span>
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'rgba(212, 175, 55, 0.2)', border: '1px solid rgba(212, 175, 55, 0.4)' }}>
              <ArrowRight className="w-5 h-5" style={{ color: '#d4af37' }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
