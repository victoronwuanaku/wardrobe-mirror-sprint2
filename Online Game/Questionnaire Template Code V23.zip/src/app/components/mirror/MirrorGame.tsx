/**
 * ============================================================================
 * WARDROBE MIRROR - ITEM-BASED DIAGNOSTIC
 * ============================================================================
 * 
 * A mobile garment diagnostic tool exploring wardrobe behavior through
 * item-by-item questioning with 10 diverse clothing items.
 * 
 * Automatically emails CSV and JSON data to researcher.
 * 
 * ============================================================================
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, Check, X, Info, Download, FileDown, RotateCcw,
  Sparkles, TrendingUp, Package, Scissors, ShoppingBag, Home,
  Heart, Wrench, DoorOpen, Compass, Mail, Share2, Clock,
  Euro, Calendar, Repeat, Droplet, Users, AlertCircle, Gift,
  Recycle, Trash2, Star, Award, ArrowLeft, Briefcase, PartyPopper,
  Target, Minus
} from 'lucide-react';
import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  PolarRadiusAxis
} from 'recharts';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface ValueMeters {
  social: number;
  emotional: number;
  functional: number;
  inflowOutflow: number;
}

interface GarmentItem {
  id: string;
  name: string;
  image: string;
  category: string;
}

interface ItemResponse {
  itemId: string;
  itemName: string;
  ownership: 'wear-often' | 'rarely-wear' | 'discarded' | 'never-owned';
  mainUse?: 'leisure-sport' | 'work' | 'special-occasions' | 'nothing' | 'other';
  price?: 'free' | '1-20' | '21-50' | '51-100' | '100+';
  age?: 'less-1-year' | '1-2-years' | '3-4-years' | '5-6-years' | '7-plus-years';
  inflow?: 'bought-new' | 'bought-secondhand' | 'gift' | 'borrowed-shared' | 'made-it';
  care?: string[];
  frequency?: 'every-week' | 'once-per-month' | 'once-per-season';
  repaired?: 'yes-myself' | 'yes-professionally' | 'no-but-would' | 'no';
  whyNotWear?: string[];
  reactivation?: string[];
  futurePlan?: 'keep' | 'repair-repurpose' | 'gift-donate' | 'sell' | 'throw-away';
  hadBefore?: 'yes' | 'no';
  whyDiscard?: string[];
  howLongUnused?: 'less-1-year' | '2-3-years' | '3-7-years' | 'more';
  whatDidWithIt?: 'threw-in-trash' | 'donated' | 'sold' | 'put-in-recycling' | 'gave-to-someone';
  timestamp: string;
}

interface GameData {
  sessionId: string;
  timestamp: string;
  itemsCompleted: number;
  finalValues: ValueMeters;
  responses: ItemResponse[];
  persona?: string;
}

type GameState = 'welcome' | 'item-entry' | 'path-question' | 'item-loop-end' | 'reflection';
type QuestionPath = 'A' | 'B' | 'C' | null;

interface Persona {
  name: string;
  description: string;
  icon: string;
  insight: string;
}

// ============================================================================
// CONSTANTS & GARMENT DATABASE (10 ITEMS)
// ============================================================================

const COLORS = {
  parchment: '#f5f1e8',
  gold: '#d4af37',
  mossGreen: '#1a2e1a',
  slate: '#1e293b',
  sage: '#8a9a5b',
  glassBg: 'rgba(245, 241, 232, 0.08)',
  glassBorder: 'rgba(245, 241, 232, 0.2)',
};

const GARMENT_ITEMS: GarmentItem[] = [
  { id: 'plain-tshirt', name: 'Plain T-Shirt', image: '👕', category: 'basics' },
  { id: 'denim-jacket', name: 'Denim Jacket', image: '🧥', category: 'outerwear' },
  { id: 'black-jeans', name: 'Black Jeans', image: '👖', category: 'bottoms' },
  { id: 'sneakers', name: 'White Sneakers', image: '👟', category: 'footwear' },
  { id: 'traditional-clothes', name: 'Traditional Clothes', image: '🥻', category: 'cultural' },
  { id: 'tailored-blazer', name: 'Tailored Blazer', image: '🧥', category: 'formal' },
  { id: 'vintage-scarf', name: 'Vintage Scarf', image: '🧣', category: 'accessories' },
  { id: 'leather-boots', name: 'Leather Boots', image: '🥾', category: 'footwear' },
  { id: 'graduation-robe', name: 'Graduation Robe', image: '🎓', category: 'ceremonial' },
  { id: 'sports-shorts', name: 'Sports Shorts', image: '🩳', category: 'activewear' },
];

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function generateSessionId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function calculateItemScore(response: ItemResponse): Partial<ValueMeters> {
  let functional = 0;
  let emotional = 0;
  let social = 0;
  let inflowOutflow = 0;

  if (response.ownership === 'wear-often') {
    functional += 15;
    inflowOutflow -= 10;

    if (response.frequency === 'every-week') {
      functional += 20;
      emotional += 10;
      inflowOutflow -= 15;
    } else if (response.frequency === 'once-per-month') {
      functional += 15;
      inflowOutflow -= 10;
    }

    if (response.age === '7-plus-years') {
      emotional += 20;
      functional += 15;
      inflowOutflow -= 15;
    } else if (response.age === '5-6-years') {
      emotional += 15;
      functional += 10;
      inflowOutflow -= 10;
    }

    if (response.inflow === 'bought-secondhand' || response.inflow === 'made-it') {
      emotional += 15;
      functional += 10;
      social -= 5;
      inflowOutflow -= 10;
    } else if (response.inflow === 'gift') {
      emotional += 20;
      inflowOutflow -= 10;
    }

    if (response.repaired === 'yes-myself' || response.repaired === 'yes-professionally') {
      functional += 20;
      emotional += 15;
      inflowOutflow -= 15;
    }

    if (response.price === '100+') {
      social += 10;
      functional += 5;
    }
  }

  if (response.ownership === 'rarely-wear') {
    functional -= 20;
    inflowOutflow += 15;

    if (response.whyNotWear?.includes('out-of-style')) {
      social += 15;
      inflowOutflow += 10;
    }
    if (response.whyNotWear?.includes('doesnt-fit')) {
      emotional += 10;
      inflowOutflow -= 5;
    }

    if (response.futurePlan === 'gift-donate') {
      functional += 10;
      inflowOutflow += 10;
    } else if (response.futurePlan === 'keep') {
      emotional += 10;
      inflowOutflow -= 10;
    }
  }

  if (response.ownership === 'discarded' && response.hadBefore === 'yes') {
    inflowOutflow += 20;

    if (response.whyDiscard?.includes('out-of-style')) {
      social += 10;
      inflowOutflow += 10;
    }
    if (response.whatDidWithIt === 'donated' || response.whatDidWithIt === 'gave-to-someone') {
      functional += 10;
      emotional += 5;
    }
  }

  return { functional, emotional, social, inflowOutflow };
}

function aggregateValues(responses: ItemResponse[]): ValueMeters {
  const base: ValueMeters = { social: 50, emotional: 50, functional: 50, inflowOutflow: 50 };
  
  responses.forEach(response => {
    const scores = calculateItemScore(response);
    base.social += scores.social || 0;
    base.emotional += scores.emotional || 0;
    base.functional += scores.functional || 0;
    base.inflowOutflow += scores.inflowOutflow || 0;
  });

  return {
    social: Math.max(0, Math.min(100, base.social)),
    emotional: Math.max(0, Math.min(100, base.emotional)),
    functional: Math.max(0, Math.min(100, base.functional)),
    inflowOutflow: Math.max(0, Math.min(100, base.inflowOutflow)),
  };
}

function calculatePersona(values: ValueMeters, responses: ItemResponse[]): Persona {
  const { emotional, social, functional, inflowOutflow } = values;
  
  const repairCount = responses.filter(r => 
    r.repaired === 'yes-myself' || r.repaired === 'yes-professionally'
  ).length;
  const totalOwned = responses.filter(r => r.ownership !== 'never-owned').length;
  const repairRate = totalOwned > 0 ? repairCount / totalOwned : 0;

  if (repairRate > 0.5 && emotional > 60 && inflowOutflow < 45) {
    return {
      name: 'The Stitch-Witch',
      icon: '🪡',
      description: 'You heal your wardrobe rather than replace it. Every mended seam is a testament to care. Your clothing holds stories of resurrection.',
      insight: 'Your repair ethic is rare and valuable. But ask: do you mend only from love, or also from fear of letting go?',
    };
  }

  const oldItems = responses.filter(r => 
    r.age === '5+-years' || r.age === '2-5-years'
  ).length;
  
  if (oldItems > responses.length * 0.5 && emotional > 65 && inflowOutflow < 40) {
    return {
      name: 'The Memory Keeper',
      icon: '📖',
      description: 'Every garment tells a story. You hold onto pieces for the moments they represent. Your wardrobe is an archive of experiences.',
      insight: 'Your attachment creates meaning. But which stories still serve you, and which have you outgrown?',
    };
  }

  if (functional > 70 && emotional < 45 && social < 50) {
    return {
      name: 'The Functional Minimalist',
      icon: '⚙️',
      description: 'Purpose drives every decision. You view clothing as tools that must earn their place through performance.',
      insight: 'Your clarity is enviable. But does pure function leave room for joy, whimsy, or self-expression?',
    };
  }

  return {
    name: 'The Harmonist',
    icon: '⚖️',
    description: 'No single value dominates your wardrobe life. You balance sentiment with practicality. Your wardrobe reflects measured moderation.',
    insight: 'Your equilibrium is rare in a culture of extremes. Does this balance reflect contentment, or indecision?',
  };
}

function exportGameData(data: GameData): void {
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `wardrobe-diagnostic-${data.sessionId}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function exportCSV(data: GameData): void {
  const headers = [
    'Session ID', 'Timestamp', 'Item Name', 'Ownership', 'Price', 'Age', 'Inflow',
    'Frequency', 'Repaired', 'Why Not Wear', 'Future Plan'
  ];
  const rows = data.responses.map(r => [
    data.sessionId, r.timestamp, r.itemName, r.ownership, r.price || '', r.age || '',
    r.inflow || '', r.frequency || '', r.repaired || '', (r.whyNotWear || []).join(';'),
    r.futurePlan || ''
  ]);
  const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `wardrobe-diagnostic-${data.sessionId}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function generateCSVString(data: GameData): string {
  const headers = [
    'Session ID', 'Timestamp', 'Item Name', 'Ownership', 'Price', 'Age', 'Inflow',
    'Frequency', 'Repaired', 'Why Not Wear', 'Future Plan'
  ];
  const rows = data.responses.map(r => [
    data.sessionId, r.timestamp, r.itemName, r.ownership, r.price || '', r.age || '',
    r.inflow || '', r.frequency || '', r.repaired || '', (r.whyNotWear || []).join(';'),
    r.futurePlan || ''
  ]);
  return [headers, ...rows].map(row => row.join(',')).join('\n');
}

async function emailDataToResearcher(data: GameData): Promise<boolean> {
  try {
    // Get Supabase project details
    const { projectId, publicAnonKey } = await import('/utils/supabase/info');
    
    console.log('📧 Preparing to send research data...');
    console.log('Session ID:', data.sessionId);
    console.log('Items completed:', data.itemsCompleted);
    
    // Prepare data for email
    const csvData = generateCSVString(data);
    const jsonData = data;

    // Call backend email endpoint
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-cfcad018/send-research-data`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({
          sessionId: data.sessionId,
          csvData,
          jsonData,
          itemsCompleted: data.itemsCompleted,
        }),
      }
    );

    console.log('Backend response status:', response.status);
    const result = await response.json();
    console.log('Backend response:', result);

    if (result.success) {
      console.log('✅ Email sent successfully to researcher');
      console.log('Email ID:', result.emailId);
      return true;
    } else {
      console.error('❌ Email failed:', result.error);
      console.error('Full error response:', result);
      
      // Fallback: download files locally
      exportCSV(data);
      exportGameData(data);
      
      // Show detailed error to help with debugging
      const errorMsg = result.error || 'Unknown error';
      alert(`📧 Email Error: ${errorMsg}\n\nFiles have been downloaded. Please email them to hamed.m.nigje@gmail.com\n\nIf you see "API key is invalid", please check that your RESEND_API_KEY is set correctly in the Supabase dashboard.`);
      return false;
    }
  } catch (error) {
    console.error('❌ Error sending email:', error);
    
    // Fallback: download files locally
    exportCSV(data);
    exportGameData(data);
    
    alert(`📧 Network Error: Unable to reach email server.\n\nFiles have been downloaded. Please email them to hamed.m.nigje@gmail.com`);
    return false;
  }
}

// ============================================================================
// UI COMPONENTS
// ============================================================================

function SelectionTile({ 
  label, 
  selected, 
  onClick,
  icon,
  description 
}: { 
  label: string; 
  selected: boolean; 
  onClick: () => void;
  icon?: React.ReactNode;
  description?: string;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full p-5 rounded-2xl transition-all duration-300 text-left relative overflow-hidden"
      style={{
        background: selected ? COLORS.glassBg : 'rgba(245, 241, 232, 0.04)',
        border: selected ? `1px solid ${COLORS.gold}` : `1px solid ${COLORS.glassBorder}`,
        boxShadow: selected ? `0 0 30px ${COLORS.gold}40` : 'none',
      }}
    >
      <div className="flex items-start gap-3">
        {icon && (
          <div style={{ color: selected ? COLORS.gold : COLORS.parchment }}>
            {icon}
          </div>
        )}
        <div className="flex-1">
          <div 
            style={{ 
              fontFamily: 'Georgia, serif',
              color: selected ? COLORS.gold : COLORS.parchment,
              fontWeight: selected ? 500 : 300,
            }}
          >
            {label}
          </div>
          {description && (
            <div 
              className="text-xs mt-1"
              style={{ color: 'rgba(245, 241, 232, 0.6)' }}
            >
              {description}
            </div>
          )}
        </div>
        {selected && (
          <Check className="w-5 h-5" style={{ color: COLORS.gold }} strokeWidth={2.5} />
        )}
      </div>
    </button>
  );
}

function ContinueButton({ 
  onClick, 
  disabled,
  label = 'Continue'
}: { 
  onClick: () => void; 
  disabled?: boolean;
  label?: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full py-4 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
      style={{
        background: disabled ? 'rgba(245, 241, 232, 0.1)' : `linear-gradient(135deg, ${COLORS.gold}, #b8941f)`,
        color: disabled ? 'rgba(245, 241, 232, 0.3)' : COLORS.mossGreen,
        fontSize: '0.875rem',
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        fontWeight: 500,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
      }}
    >
      {label}
      <ArrowRight className="w-4 h-4" strokeWidth={2} />
    </button>
  );
}

// ============================================================================
// MAIN GAME COMPONENT
// ============================================================================

export function MirrorGame() {
  const [gameState, setGameState] = useState<GameState>('welcome');
  const [sessionId] = useState(generateSessionId());
  const [sessionStartTime] = useState(new Date().toISOString());
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [currentResponse, setCurrentResponse] = useState<Partial<ItemResponse>>({});
  const [allResponses, setAllResponses] = useState<ItemResponse[]>([]);
  const [questionPath, setQuestionPath] = useState<QuestionPath>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [emailSent, setEmailSent] = useState(false);

  const currentItem = GARMENT_ITEMS[currentItemIndex];
  const finalValues = aggregateValues(allResponses);
  const persona = allResponses.length > 0 ? calculatePersona(finalValues, allResponses) : null;

  const handleStartGame = () => {
    setGameState('item-entry');
  };

  const handleOwnershipSelect = (ownership: 'wear-often' | 'rarely-wear' | 'discarded' | 'never-owned') => {
    setCurrentResponse({
      itemId: currentItem.id,
      itemName: currentItem.name,
      ownership,
      timestamp: new Date().toISOString(),
    });

    if (ownership === 'never-owned') {
      // Skip to next item
      const newResponse: ItemResponse = {
        itemId: currentItem.id,
        itemName: currentItem.name,
        ownership: 'never-owned',
        timestamp: new Date().toISOString(),
      };
      setAllResponses([...allResponses, newResponse]);
      proceedToNextItem();
    } else if (ownership === 'wear-often') {
      setQuestionPath('A');
      setCurrentQuestionIndex(-1); // Start with mainUse question
      setGameState('path-question');
    } else if (ownership === 'rarely-wear') {
      setQuestionPath('B');
      setCurrentQuestionIndex(-1); // Start with mainUse question
      setGameState('path-question');
    } else if (ownership === 'discarded') {
      setQuestionPath('C');
      setCurrentQuestionIndex(-1); // Start with mainUse question
      setGameState('path-question');
    }
  };

  const handleAnswer = (key: string, value: any) => {
    setCurrentResponse({ ...currentResponse, [key]: value });
    
    // Auto-advance for single-choice questions after a brief delay
    setTimeout(() => {
      handleContinue();
    }, 400);
  };

  const handleContinue = () => {
    if (questionPath === 'A') {
      if (currentQuestionIndex < 5) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        completeItemResponse();
      }
    } else if (questionPath === 'B') {
      if (currentQuestionIndex < 4) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        completeItemResponse();
      }
    } else if (questionPath === 'C') {
      if (currentQuestionIndex < 5) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        completeItemResponse();
      }
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > -1) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    } else {
      // Go back to ownership selection
      setGameState('item-entry');
      setQuestionPath(null);
      setCurrentQuestionIndex(0);
    }
  };

  const completeItemResponse = () => {
    const newResponse = currentResponse as ItemResponse;
    setAllResponses([...allResponses, newResponse]);
    
    if (currentItemIndex < GARMENT_ITEMS.length - 1) {
      setGameState('item-loop-end');
    } else {
      finishGame();
    }
  };

  const proceedToNextItem = () => {
    if (currentItemIndex < GARMENT_ITEMS.length - 1) {
      setCurrentItemIndex(currentItemIndex + 1);
      setCurrentResponse({});
      setQuestionPath(null);
      setCurrentQuestionIndex(0);
      setGameState('item-entry');
    } else {
      finishGame();
    }
  };

  const finishGame = async () => {
    setGameState('reflection');
    
    // Auto-email data
    const gameData: GameData = {
      sessionId,
      timestamp: sessionStartTime,
      itemsCompleted: allResponses.length,
      finalValues,
      responses: allResponses,
      persona: persona?.name,
    };
    
    const success = await emailDataToResearcher(gameData);
    setEmailSent(success);
  };

  const exportJSON = (data: GameData) => {
    exportGameData(data);
  };

  const handleStartNewRun = () => {
    // Reset all state
    window.location.reload();
  };

  const handleShareWithOthers = async () => {
    const url = window.location.href;
    
    // Try native Web Share API first (works on mobile)
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'The Wardrobe Mirror',
          text: 'Discover your clothing decision-making patterns with this wardrobe diagnostic tool',
          url: url,
        });
        console.log('✅ Shared successfully');
      } catch (error) {
        // User cancelled or error occurred
        console.log('Share cancelled or failed:', error);
      }
    } else {
      // Fallback: Copy to clipboard
      try {
        await navigator.clipboard.writeText(url);
        alert('✅ Link copied to clipboard!\n\nShare this link with others so they can participate in the research.');
      } catch (error) {
        // Final fallback: show URL in alert
        alert(`Share this link:\n\n${url}`);
      }
    }
  };

  const renderPathQuestions = () => {
    if (!currentResponse.ownership) return null;

    const isAnswered = (key: string) => {
      return currentResponse[key as keyof ItemResponse] !== undefined;
    };

    if (questionPath === 'A') {
      // Path A: Wear Often - 7 questions (including mainUse at -1)
      switch (currentQuestionIndex) {
        case -1:
          return (
            <QuestionScreen title="What do you mainly use it for?" subtitle={currentItem.name} icon={<Target className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Leisure or sport" selected={currentResponse.mainUse === 'leisure-sport'} onClick={() => handleAnswer('mainUse', 'leisure-sport')} icon={<Heart className="w-5 h-5" />} />
                <SelectionTile label="Work" selected={currentResponse.mainUse === 'work'} onClick={() => handleAnswer('mainUse', 'work')} icon={<Briefcase className="w-5 h-5" />} />
                <SelectionTile label="Special occasions" selected={currentResponse.mainUse === 'special-occasions'} onClick={() => handleAnswer('mainUse', 'special-occasions')} icon={<PartyPopper className="w-5 h-5" />} />
                <SelectionTile label="Nothing" selected={currentResponse.mainUse === 'nothing'} onClick={() => handleAnswer('mainUse', 'nothing')} icon={<Minus className="w-5 h-5" />} />
                <SelectionTile label="Other" selected={currentResponse.mainUse === 'other'} onClick={() => handleAnswer('mainUse', 'other')} icon={<Compass className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 0:
          return (
            <QuestionScreen title="About how much did it cost?" subtitle={currentItem.name} icon={<Euro className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Free" selected={currentResponse.price === 'free'} onClick={() => handleAnswer('price', 'free')} icon={<Gift className="w-5 h-5" />} />
                <SelectionTile label="€1–20" selected={currentResponse.price === '1-20'} onClick={() => handleAnswer('price', '1-20')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€21–50" selected={currentResponse.price === '21-50'} onClick={() => handleAnswer('price', '21-50')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€51–100" selected={currentResponse.price === '51-100'} onClick={() => handleAnswer('price', '51-100')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€100+" selected={currentResponse.price === '100+'} onClick={() => handleAnswer('price', '100+')} icon={<Euro className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 1:
          return (
            <QuestionScreen title="How often do you wear it?" subtitle={currentItem.name} icon={<Repeat className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="At least once a week" selected={currentResponse.frequency === 'every-week'} onClick={() => handleAnswer('frequency', 'every-week')} icon={<Star className="w-5 h-5" />} />
                <SelectionTile label="At least once a month" selected={currentResponse.frequency === 'once-per-month'} onClick={() => handleAnswer('frequency', 'once-per-month')} icon={<Repeat className="w-5 h-5" />} />
                <SelectionTile label="At least once each season" selected={currentResponse.frequency === 'once-per-season'} onClick={() => handleAnswer('frequency', 'once-per-season')} icon={<Clock className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 2:
          return (
            <QuestionScreen title="How long have you had it?" subtitle={currentItem.name} icon={<Calendar className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Less than 1 year" selected={currentResponse.age === 'less-1-year'} onClick={() => handleAnswer('age', 'less-1-year')} icon={<Sparkles className="w-5 h-5" />} />
                <SelectionTile label="1–2 years" selected={currentResponse.age === '1-2-years'} onClick={() => handleAnswer('age', '1-2-years')} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="3–4 years" selected={currentResponse.age === '3-4-years'} onClick={() => handleAnswer('age', '3-4-years')} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="5–6 years" selected={currentResponse.age === '5-6-years'} onClick={() => handleAnswer('age', '5-6-years')} icon={<Clock className="w-5 h-5" />} />
                <SelectionTile label="7+ years" selected={currentResponse.age === '7-plus-years'} onClick={() => handleAnswer('age', '7-plus-years')} icon={<Heart className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 3:
          return (
            <QuestionScreen title="How did you get it?" subtitle={currentItem.name} icon={<ShoppingBag className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Bought new" selected={currentResponse.inflow === 'bought-new'} onClick={() => handleAnswer('inflow', 'bought-new')} icon={<ShoppingBag className="w-5 h-5" />} />
                <SelectionTile label="Bought second-hand" selected={currentResponse.inflow === 'bought-secondhand'} onClick={() => handleAnswer('inflow', 'bought-secondhand')} icon={<Recycle className="w-5 h-5" />} />
                <SelectionTile label="Gift" selected={currentResponse.inflow === 'gift'} onClick={() => handleAnswer('inflow', 'gift')} icon={<Gift className="w-5 h-5" />} />
                <SelectionTile label="Borrowed / shared" selected={currentResponse.inflow === 'borrowed-shared'} onClick={() => handleAnswer('inflow', 'borrowed-shared')} icon={<Users className="w-5 h-5" />} />
                <SelectionTile label="Made it" selected={currentResponse.inflow === 'made-it'} onClick={() => handleAnswer('inflow', 'made-it')} icon={<Scissors className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 4:
          return (
            <QuestionScreen title="How do you usually care for it?" subtitle="Select one" icon={<Droplet className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Machine wash" selected={currentResponse.care?.[0] === 'machine-wash'} onClick={() => handleAnswer('care', ['machine-wash'])} icon={<Repeat className="w-5 h-5" />} />
                <SelectionTile label="Hand wash" selected={currentResponse.care?.[0] === 'hand-wash'} onClick={() => handleAnswer('care', ['hand-wash'])} icon={<Droplet className="w-5 h-5" />} />
                <SelectionTile label="Dry clean" selected={currentResponse.care?.[0] === 'dry-clean'} onClick={() => handleAnswer('care', ['dry-clean'])} icon={<Sparkles className="w-5 h-5" />} />
                <SelectionTile label="Air dry" selected={currentResponse.care?.[0] === 'air-dry'} onClick={() => handleAnswer('care', ['air-dry'])} icon={<Clock className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 5:
          return (
            <QuestionScreen title="Have you ever repaired it?" subtitle={currentItem.name} icon={<Wrench className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Yes, myself" selected={currentResponse.repaired === 'yes-myself'} onClick={() => handleAnswer('repaired', 'yes-myself')} icon={<Wrench className="w-5 h-5" />} />
                <SelectionTile label="Yes, professionally" selected={currentResponse.repaired === 'yes-professionally'} onClick={() => handleAnswer('repaired', 'yes-professionally')} icon={<Scissors className="w-5 h-5" />} />
                <SelectionTile label="No, but I would" selected={currentResponse.repaired === 'no-but-would'} onClick={() => handleAnswer('repaired', 'no-but-would')} icon={<Heart className="w-5 h-5" />} />
                <SelectionTile label="No" selected={currentResponse.repaired === 'no'} onClick={() => handleAnswer('repaired', 'no')} icon={<X className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
      }
    } else if (questionPath === 'B') {
      // Path B: Rarely Wear - 6 questions (including mainUse at -1)
      switch (currentQuestionIndex) {
        case -1:
          return (
            <QuestionScreen title="What did you mainly use it for?" subtitle={currentItem.name} icon={<Target className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Leisure or sport" selected={currentResponse.mainUse === 'leisure-sport'} onClick={() => handleAnswer('mainUse', 'leisure-sport')} icon={<Heart className="w-5 h-5" />} />
                <SelectionTile label="Work" selected={currentResponse.mainUse === 'work'} onClick={() => handleAnswer('mainUse', 'work')} icon={<Briefcase className="w-5 h-5" />} />
                <SelectionTile label="Special occasions" selected={currentResponse.mainUse === 'special-occasions'} onClick={() => handleAnswer('mainUse', 'special-occasions')} icon={<PartyPopper className="w-5 h-5" />} />
                <SelectionTile label="Nothing" selected={currentResponse.mainUse === 'nothing'} onClick={() => handleAnswer('mainUse', 'nothing')} icon={<Minus className="w-5 h-5" />} />
                <SelectionTile label="Other" selected={currentResponse.mainUse === 'other'} onClick={() => handleAnswer('mainUse', 'other')} icon={<Compass className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 0:
          return (
            <QuestionScreen title="About how much did it cost?" subtitle={currentItem.name} icon={<Euro className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Free" selected={currentResponse.price === 'free'} onClick={() => handleAnswer('price', 'free')} icon={<Gift className="w-5 h-5" />} />
                <SelectionTile label="€1–20" selected={currentResponse.price === '1-20'} onClick={() => handleAnswer('price', '1-20')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€21–50" selected={currentResponse.price === '21-50'} onClick={() => handleAnswer('price', '21-50')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€51–100" selected={currentResponse.price === '51-100'} onClick={() => handleAnswer('price', '51-100')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€100+" selected={currentResponse.price === '100+'} onClick={() => handleAnswer('price', '100+')} icon={<Euro className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 1:
          return (
            <QuestionScreen title="How long have you had it?" subtitle={currentItem.name} icon={<Calendar className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Less than 1 year" selected={currentResponse.age === 'less-1-year'} onClick={() => handleAnswer('age', 'less-1-year')} icon={<Sparkles className="w-5 h-5" />} />
                <SelectionTile label="1–2 years" selected={currentResponse.age === '1-2-years'} onClick={() => handleAnswer('age', '1-2-years')} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="3–4 years" selected={currentResponse.age === '3-4-years'} onClick={() => handleAnswer('age', '3-4-years')} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="5–6 years" selected={currentResponse.age === '5-6-years'} onClick={() => handleAnswer('age', '5-6-years')} icon={<Clock className="w-5 h-5" />} />
                <SelectionTile label="7+ years" selected={currentResponse.age === '7-plus-years'} onClick={() => handleAnswer('age', '7-plus-years')} icon={<Heart className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 2:
          return (
            <QuestionScreen title="How did you get it?" subtitle={currentItem.name} icon={<ShoppingBag className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Bought new" selected={currentResponse.inflow === 'bought-new'} onClick={() => handleAnswer('inflow', 'bought-new')} icon={<ShoppingBag className="w-5 h-5" />} />
                <SelectionTile label="Bought second-hand" selected={currentResponse.inflow === 'bought-secondhand'} onClick={() => handleAnswer('inflow', 'bought-secondhand')} icon={<Recycle className="w-5 h-5" />} />
                <SelectionTile label="Gift" selected={currentResponse.inflow === 'gift'} onClick={() => handleAnswer('inflow', 'gift')} icon={<Gift className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 3:
          return (
            <QuestionScreen title="Why don't you wear it often?" subtitle="Choose one" icon={<AlertCircle className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Doesn't fit" selected={currentResponse.whyNotWear?.[0] === 'doesnt-fit'} onClick={() => handleAnswer('whyNotWear', ['doesnt-fit'])} icon={<AlertCircle className="w-5 h-5" />} />
                <SelectionTile label="Out of style" selected={currentResponse.whyNotWear?.[0] === 'out-of-style'} onClick={() => handleAnswer('whyNotWear', ['out-of-style'])} icon={<TrendingUp className="w-5 h-5" />} />
                <SelectionTile label="Seasonal" selected={currentResponse.whyNotWear?.[0] === 'seasonal'} onClick={() => handleAnswer('whyNotWear', ['seasonal'])} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="Forgot about it" selected={currentResponse.whyNotWear?.[0] === 'forgot'} onClick={() => handleAnswer('whyNotWear', ['forgot'])} icon={<Package className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 4:
          return (
            <QuestionScreen title="What do you plan to do with it?" subtitle={currentItem.name} icon={<Compass className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Keep it" selected={currentResponse.futurePlan === 'keep'} onClick={() => handleAnswer('futurePlan', 'keep')} icon={<Heart className="w-5 h-5" />} />
                <SelectionTile label="Repair or repurpose" selected={currentResponse.futurePlan === 'repair-repurpose'} onClick={() => handleAnswer('futurePlan', 'repair-repurpose')} icon={<Wrench className="w-5 h-5" />} />
                <SelectionTile label="Gift or donate" selected={currentResponse.futurePlan === 'gift-donate'} onClick={() => handleAnswer('futurePlan', 'gift-donate')} icon={<Gift className="w-5 h-5" />} />
                <SelectionTile label="Sell it" selected={currentResponse.futurePlan === 'sell'} onClick={() => handleAnswer('futurePlan', 'sell')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="Throw away" selected={currentResponse.futurePlan === 'throw-away'} onClick={() => handleAnswer('futurePlan', 'throw-away')} icon={<Trash2 className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
      }
    } else if (questionPath === 'C') {
      // Path C: Discarded - 7 questions (including mainUse at -1 and howLongUnused at 4)
      switch (currentQuestionIndex) {
        case -1:
          return (
            <QuestionScreen title="What did you mainly use it for?" subtitle={currentItem.name} icon={<Target className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Leisure or sport" selected={currentResponse.mainUse === 'leisure-sport'} onClick={() => handleAnswer('mainUse', 'leisure-sport')} icon={<Heart className="w-5 h-5" />} />
                <SelectionTile label="Work" selected={currentResponse.mainUse === 'work'} onClick={() => handleAnswer('mainUse', 'work')} icon={<Briefcase className="w-5 h-5" />} />
                <SelectionTile label="Special occasions" selected={currentResponse.mainUse === 'special-occasions'} onClick={() => handleAnswer('mainUse', 'special-occasions')} icon={<PartyPopper className="w-5 h-5" />} />
                <SelectionTile label="Nothing" selected={currentResponse.mainUse === 'nothing'} onClick={() => handleAnswer('mainUse', 'nothing')} icon={<Minus className="w-5 h-5" />} />
                <SelectionTile label="Other" selected={currentResponse.mainUse === 'other'} onClick={() => handleAnswer('mainUse', 'other')} icon={<Compass className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 0:
          return (
            <QuestionScreen title="About how much did it cost?" subtitle={currentItem.name} icon={<Euro className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Free" selected={currentResponse.price === 'free'} onClick={() => handleAnswer('price', 'free')} icon={<Gift className="w-5 h-5" />} />
                <SelectionTile label="€1–20" selected={currentResponse.price === '1-20'} onClick={() => handleAnswer('price', '1-20')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€21–50" selected={currentResponse.price === '21-50'} onClick={() => handleAnswer('price', '21-50')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€51–100" selected={currentResponse.price === '51-100'} onClick={() => handleAnswer('price', '51-100')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="€100+" selected={currentResponse.price === '100+'} onClick={() => handleAnswer('price', '100+')} icon={<Euro className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 1:
          return (
            <QuestionScreen title="How long did you have it?" subtitle={currentItem.name} icon={<Calendar className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Less than 1 year" selected={currentResponse.age === 'less-1-year'} onClick={() => handleAnswer('age', 'less-1-year')} icon={<Sparkles className="w-5 h-5" />} />
                <SelectionTile label="1–2 years" selected={currentResponse.age === '1-2-years'} onClick={() => handleAnswer('age', '1-2-years')} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="3–4 years" selected={currentResponse.age === '3-4-years'} onClick={() => handleAnswer('age', '3-4-years')} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="5–6 years" selected={currentResponse.age === '5-6-years'} onClick={() => handleAnswer('age', '5-6-years')} icon={<Clock className="w-5 h-5" />} />
                <SelectionTile label="7+ years" selected={currentResponse.age === '7-plus-years'} onClick={() => handleAnswer('age', '7-plus-years')} icon={<Heart className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 2:
          return (
            <QuestionScreen title="How did you get it?" subtitle={currentItem.name} icon={<ShoppingBag className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Bought new" selected={currentResponse.inflow === 'bought-new'} onClick={() => handleAnswer('inflow', 'bought-new')} icon={<ShoppingBag className="w-5 h-5" />} />
                <SelectionTile label="Bought second-hand" selected={currentResponse.inflow === 'bought-secondhand'} onClick={() => handleAnswer('inflow', 'bought-secondhand')} icon={<Recycle className="w-5 h-5" />} />
                <SelectionTile label="Gift" selected={currentResponse.inflow === 'gift'} onClick={() => handleAnswer('inflow', 'gift')} icon={<Gift className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 3:
          return (
            <QuestionScreen title="Why did you discard it?" subtitle="Choose one" icon={<AlertCircle className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Out of style" selected={currentResponse.whyDiscard?.[0] === 'out-of-style'} onClick={() => handleAnswer('whyDiscard', ['out-of-style'])} icon={<TrendingUp className="w-5 h-5" />} />
                <SelectionTile label="Doesn't fit" selected={currentResponse.whyDiscard?.[0] === 'doesnt-fit'} onClick={() => handleAnswer('whyDiscard', ['doesnt-fit'])} icon={<AlertCircle className="w-5 h-5" />} />
                <SelectionTile label="Seasonal" selected={currentResponse.whyDiscard?.[0] === 'seasonal'} onClick={() => handleAnswer('whyDiscard', ['seasonal'])} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="Forgot about it" selected={currentResponse.whyDiscard?.[0] === 'forgot'} onClick={() => handleAnswer('whyDiscard', ['forgot'])} icon={<Package className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 4:
          return (
            <QuestionScreen title="How long did it stay unused before you threw it away?" subtitle={currentItem.name} icon={<Clock className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Less than 1 year" selected={currentResponse.howLongUnused === 'less-1-year'} onClick={() => handleAnswer('howLongUnused', 'less-1-year')} icon={<Sparkles className="w-5 h-5" />} />
                <SelectionTile label="2 to 3 years" selected={currentResponse.howLongUnused === '2-3-years'} onClick={() => handleAnswer('howLongUnused', '2-3-years')} icon={<Clock className="w-5 h-5" />} />
                <SelectionTile label="3 to 7 years" selected={currentResponse.howLongUnused === '3-7-years'} onClick={() => handleAnswer('howLongUnused', '3-7-years')} icon={<Calendar className="w-5 h-5" />} />
                <SelectionTile label="More" selected={currentResponse.howLongUnused === 'more'} onClick={() => handleAnswer('howLongUnused', 'more')} icon={<TrendingUp className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
        case 5:
          return (
            <QuestionScreen title="What did you do with it?" subtitle={currentItem.name} icon={<Compass className="w-7 h-7" />}>
              <div className="space-y-3">
                <SelectionTile label="Threw in trash" selected={currentResponse.whatDidWithIt === 'threw-in-trash'} onClick={() => handleAnswer('whatDidWithIt', 'threw-in-trash')} icon={<Trash2 className="w-5 h-5" />} />
                <SelectionTile label="Donated" selected={currentResponse.whatDidWithIt === 'donated'} onClick={() => handleAnswer('whatDidWithIt', 'donated')} icon={<Gift className="w-5 h-5" />} />
                <SelectionTile label="Sold" selected={currentResponse.whatDidWithIt === 'sold'} onClick={() => handleAnswer('whatDidWithIt', 'sold')} icon={<Euro className="w-5 h-5" />} />
                <SelectionTile label="Put in recycling" selected={currentResponse.whatDidWithIt === 'put-in-recycling'} onClick={() => handleAnswer('whatDidWithIt', 'put-in-recycling')} icon={<Recycle className="w-5 h-5" />} />
                <SelectionTile label="Gave to someone" selected={currentResponse.whatDidWithIt === 'gave-to-someone'} onClick={() => handleAnswer('whatDidWithIt', 'gave-to-someone')} icon={<Users className="w-5 h-5" />} />
              </div>
            </QuestionScreen>
          );
      }
    }

    return null;
  };

  if (gameState === 'welcome') {
    return (
      <div 
        className="min-h-screen flex flex-col items-center justify-center p-6"
        style={{ background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 100%)` }}
      >
        <div className="max-w-md w-full space-y-12 text-center">
          <div className="space-y-6">
            <div className="flex items-center justify-center gap-3">
              <Sparkles className="w-7 h-7" style={{ color: COLORS.gold }} />
              <h1 className="text-4xl" style={{ fontFamily: 'Georgia, serif', color: COLORS.parchment }}>
                The Wardrobe Mirror
              </h1>
              <Sparkles className="w-7 h-7" style={{ color: COLORS.gold }} />
            </div>
            <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
              An item-based diagnostic exploring the values<br />that shape our relationship with clothing
            </p>
          </div>

          <div className="rounded-3xl p-8 space-y-6" style={{ background: COLORS.glassBg, border: `1px solid ${COLORS.glassBorder}` }}>
            <h2 className="text-xl" style={{ fontFamily: 'Georgia, serif', color: COLORS.parchment }}>How It Works</h2>
            <div className="space-y-4 text-sm text-left" style={{ color: 'rgba(245, 241, 232, 0.8)' }}>
              <p><strong style={{ color: COLORS.gold }}>1.</strong> We'll show you 10 common garments</p>
              <p><strong style={{ color: COLORS.gold }}>2.</strong> Answer questions about ownership and use</p>
              <p><strong style={{ color: COLORS.gold }}>3.</strong> Data auto-emailed to researcher</p>
            </div>
          </div>

          <ContinueButton onClick={handleStartGame} label="Begin Diagnostic" />
        </div>
      </div>
    );
  }

  if (gameState === 'item-entry') {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen flex flex-col p-6"
        style={{ background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 100%)` }}
      >
        <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-center space-y-12">
          <div className="w-full aspect-square rounded-3xl flex items-center justify-center" style={{ background: COLORS.glassBg, border: `1px solid ${COLORS.glassBorder}` }}>
            <div className="text-9xl">{currentItem.image}</div>
          </div>

          <div className="text-center space-y-4">
            <h2 className="text-2xl" style={{ fontFamily: 'Georgia, serif', color: COLORS.parchment }}>
              Do you own something<br />like this?
            </h2>
            <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.6)' }}>{currentItem.name}</p>
            <p className="text-xs" style={{ color: COLORS.gold }}>Item {currentItemIndex + 1} of {GARMENT_ITEMS.length}</p>
          </div>

          <div className="space-y-3">
            <SelectionTile label="Yes, and I wear it often" selected={false} onClick={() => handleOwnershipSelect('wear-often')} icon={<Heart className="w-5 h-5" />} />
            <SelectionTile label="Yes, but I rarely wear it" selected={false} onClick={() => handleOwnershipSelect('rarely-wear')} icon={<Package className="w-5 h-5" />} />
            <SelectionTile label="Had it before but got rid of it" selected={false} onClick={() => handleOwnershipSelect('discarded')} icon={<DoorOpen className="w-5 h-5" />} />
            <SelectionTile label="No, I don't own this" selected={false} onClick={() => handleOwnershipSelect('never-owned')} icon={<X className="w-5 h-5" />} />
          </div>
        </div>
      </motion.div>
    );
  }

  if (gameState === 'path-question') {
    const currentQuestionHasAnswer = () => {
      if (questionPath === 'A') {
        switch (currentQuestionIndex) {
          case -1: return !!currentResponse.mainUse;
          case 0: return !!currentResponse.price;
          case 1: return !!currentResponse.frequency;
          case 2: return !!currentResponse.age;
          case 3: return !!currentResponse.inflow;
          case 4: return !!currentResponse.care && currentResponse.care.length > 0;
          case 5: return !!currentResponse.repaired;
          default: return false;
        }
      } else if (questionPath === 'B') {
        switch (currentQuestionIndex) {
          case -1: return !!currentResponse.mainUse;
          case 0: return !!currentResponse.price;
          case 1: return !!currentResponse.age;
          case 2: return !!currentResponse.inflow;
          case 3: return !!currentResponse.whyNotWear && currentResponse.whyNotWear.length > 0;
          case 4: return !!currentResponse.futurePlan;
          default: return false;
        }
      } else if (questionPath === 'C') {
        switch (currentQuestionIndex) {
          case -1: return !!currentResponse.mainUse;
          case 0: return !!currentResponse.price;
          case 1: return !!currentResponse.age;
          case 2: return !!currentResponse.inflow;
          case 3: return !!currentResponse.whyDiscard && currentResponse.whyDiscard.length > 0;
          case 4: return !!currentResponse.howLongUnused;
          case 5: return !!currentResponse.whatDidWithIt;
          default: return false;
        }
      }
      return false;
    };

    return (
      <div className="min-h-screen flex flex-col p-6" style={{ background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 100%)` }}>
        <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-center space-y-8">
          {renderPathQuestions()}
          <div className="flex gap-3">
            <button
              onClick={handleBack}
              className="py-4 px-8 rounded-full text-sm"
              style={{ color: COLORS.gold, border: `1px solid ${COLORS.gold}`, background: 'transparent' }}
            >
              Back
            </button>
            <div className="flex-1">
              <ContinueButton onClick={handleContinue} disabled={!currentQuestionHasAnswer()} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'item-loop-end') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6" style={{ background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 100%)` }}>
        <div className="max-w-md w-full space-y-8 text-center">
          <div className="text-6xl">{currentItem.image}</div>
          <h2 className="text-2xl" style={{ fontFamily: 'Georgia, serif', color: COLORS.parchment }}>
            Thank you!
          </h2>
          <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
            {currentItemIndex + 1} of {GARMENT_ITEMS.length} items complete
          </p>
          <div className="space-y-3">
            <ContinueButton onClick={proceedToNextItem} label="Next Item" />
            <button
              onClick={finishGame}
              className="w-full py-3 rounded-full text-sm"
              style={{ color: COLORS.gold, border: `1px solid ${COLORS.gold}`, background: 'transparent' }}
            >
              Finish & See Results
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'reflection' && persona) {
    // Calculate completion percentage
    const completionPercentage = (allResponses.length / GARMENT_ITEMS.length) * 100;
    
    // Get encouraging message based on completion
    const getEncouragingMessage = () => {
      if (completionPercentage === 100) {
        return { emoji: '🏆', message: 'You are a legend!' };
      } else if (completionPercentage >= 80) {
        return { emoji: '⭐', message: 'You are amazing!' };
      } else if (completionPercentage >= 60) {
        return { emoji: '🎯', message: 'You are doing great!' };
      } else if (completionPercentage >= 40) {
        return { emoji: '👏', message: 'You are a hero!' };
      } else {
        return { emoji: '✨', message: 'You are here!' };
      }
    };
    
    const encouragement = getEncouragingMessage();
    
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6" style={{ background: `linear-gradient(165deg, ${COLORS.mossGreen} 0%, ${COLORS.slate} 100%)` }}>
        <div className="max-w-md w-full space-y-12 text-center">
          <div className="space-y-6">
            <div className="text-8xl mb-6">✨</div>
            <h1 className="text-4xl mb-4" style={{ fontFamily: 'Georgia, serif', color: COLORS.parchment }}>
              Thank You!
            </h1>
            <p className="text-lg leading-relaxed" style={{ color: 'rgba(245, 241, 232, 0.8)' }}>
              Your contribution to this research<br />is greatly appreciated.
            </p>
          </div>

          {/* Completion Percentage */}
          <div className="p-6 rounded-3xl" style={{ background: 'rgba(212, 175, 55, 0.15)', border: `2px solid ${COLORS.gold}` }}>
            <div className="text-6xl mb-4">{encouragement.emoji}</div>
            <h3 className="text-2xl mb-3" style={{ fontFamily: 'Georgia, serif', color: COLORS.gold }}>
              {encouragement.message}
            </h3>
            <div className="flex items-center justify-center gap-3 mb-2">
              <Award className="w-6 h-6" style={{ color: COLORS.gold }} />
              <p className="text-4xl font-bold" style={{ color: COLORS.gold }}>
                {completionPercentage.toFixed(0)}%
              </p>
              <Award className="w-6 h-6" style={{ color: COLORS.gold }} />
            </div>
            <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
              {allResponses.length} out of {GARMENT_ITEMS.length} garments covered
            </p>
          </div>

          <div className="p-8 rounded-3xl" style={{ background: COLORS.glassBg, border: `1px solid ${COLORS.glassBorder}` }}>
            {emailSent ? (
              <>
                <div className="text-5xl mb-4">✅</div>
                <h2 className="text-xl mb-3" style={{ fontFamily: 'Georgia, serif', color: COLORS.gold }}>
                  Data Sent Successfully
                </h2>
                <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
                  Your responses have been automatically emailed to the researcher.
                </p>
              </>
            ) : (
              <>
                <div className="text-5xl mb-4">📧</div>
                <h2 className="text-xl mb-3" style={{ fontFamily: 'Georgia, serif', color: COLORS.gold }}>
                  Sending Data...
                </h2>
                <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.7)' }}>
                  Your responses are being sent to the researcher.
                </p>
              </>
            )}
          </div>

          <div className="p-6 rounded-2xl" style={{ background: 'rgba(212, 175, 55, 0.1)', border: `1px solid ${COLORS.gold}` }}>
            <p className="text-xs uppercase tracking-wider mb-2" style={{ color: COLORS.gold }}>
              Wardrobe Research Initiative
            </p>
            <p className="text-xs" style={{ color: 'rgba(245, 241, 232, 0.6)' }}>
              Your privacy is protected. Session ID: {sessionId.substring(0, 12)}...
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={handleStartNewRun}
              className="w-full py-4 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
              style={{
                background: `linear-gradient(135deg, ${COLORS.gold}, #b8941f)`,
                color: COLORS.mossGreen,
                fontSize: '0.875rem',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                fontWeight: 500,
              }}
            >
              <RotateCcw className="w-4 h-4" strokeWidth={2} />
              Start New Run
            </button>

            <button
              onClick={handleShareWithOthers}
              className="w-full py-3 rounded-full text-sm transition-all duration-300 flex items-center justify-center gap-2"
              style={{ 
                color: COLORS.gold, 
                border: `1px solid ${COLORS.gold}`, 
                background: 'transparent' 
              }}
            >
              <Share2 className="w-4 h-4" strokeWidth={2} />
              Share with Others
            </button>
          </div>

          <p className="text-xs" style={{ color: 'rgba(245, 241, 232, 0.5)' }}>
            You may now close this window
          </p>
        </div>
      </div>
    );
  }

  return null;
}

// Helper component for question screens
function QuestionScreen({ title, subtitle, children, icon }: { title: string; subtitle?: string; children: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div className="space-y-6">
      {icon && (
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: COLORS.glassBg, border: `1px solid ${COLORS.gold}` }}>
            <div style={{ color: COLORS.gold }}>
              {icon}
            </div>
          </div>
        </div>
      )}
      <div className="text-center space-y-2">
        <h2 className="text-2xl" style={{ fontFamily: 'Georgia, serif', color: COLORS.parchment }}>
          {title}
        </h2>
        {subtitle && (
          <p className="text-sm" style={{ color: 'rgba(245, 241, 232, 0.6)' }}>
            {subtitle}
          </p>
        )}
      </div>
      {children}
    </div>
  );
}